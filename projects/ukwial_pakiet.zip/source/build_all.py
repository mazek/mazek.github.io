"""Ukwiał – builds every STL.  pip install manifold3d trimesh numpy
Run:  python build_all.py   -> files in ./stl  (parameters in parts.py)"""
import os, numpy as np, trimesh
import parts as P
from manifold3d import Manifold
OUT=os.path.join(os.path.dirname(__file__) or '.','stl'); os.makedirs(OUT,exist_ok=True)
def drop(m):
    b=m.bounding_box(); return m.translate([-(b[0]+b[3])/2,-(b[1]+b[4])/2,-b[2]])
def flat(m):  # leaves/arms: thickness along Z
    R=np.array([[1,0,0,0],[0,0,1,0],[0,-1,0,0.]]); return drop(m.transform(R))
O_Z=P.BASE_H+P.LID_T+P.H_O
L_v=(O_Z+P.SC['zs']-1.5-0.4)-3.5; L_h=55.5
parts={
 '01_gear15_ring_A_x6':drop(P.gearA()), '02_gear24_ring_B_x6':drop(P.gearB()), '03_gear24_center_x1':drop(P.gearC()),
 '04_leaf_A_small_x6':flat(P.leaf_A()), '05_leaf_B_large_x6':flat(P.leaf_B()), '06_leaf_crown_x1':flat(P.leaf_C()),
 '07_sleeve_A_x6':drop(P.sleeve(P.SA)[0]), '08_sleeve_B_x6':drop(P.sleeve(P.SB)[0]),
 '10_top_motor':drop(P.top('motor')), '11_base_motor_switch':drop(P.base_motor(False)),
 '12_base_motor_pwm_esp32':drop(P.base_motor(True)), '13_coupler_N20_to_hex6':drop(P.coupler()),
 '20_top_crank':drop(P.top('crank')), '21_base_crank':drop(P.base_crank()),
 '22_miter_vertical':drop(P.miter(P.BASE_H-0.5-P.ZQ)), '23_miter_horizontal':drop(P.miter(23.7)),
 '24_shaft_vertical_hex6':drop(P.hex_shaft(L_v)), '25_shaft_crank_hex6':drop(P.hex_shaft(L_h)),
 '26_crank_wheel':drop(P.crank_wheel()), '27_crank_knob':drop(P.crank_knob()),
}
for n,m in parts.items():
    me=m.to_mesh(); trimesh.Trimesh(me.vert_properties[:,:3],me.tri_verts).export(os.path.join(OUT,n+'.stl'))
    print(n, 'OK' if m.status().name=='NoError' else m.status())
