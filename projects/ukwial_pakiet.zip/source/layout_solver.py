import numpy as np
m=2.0
def rot(axis,v,t):
    axis=np.asarray(axis,float); axis=axis/np.linalg.norm(axis)
    return v*np.cos(t)+np.cross(axis,v)*np.sin(t)+axis*(axis@v)*(1-np.cos(t))
def frame(a):
    a=a/np.linalg.norm(a); up=np.array([0,0,1.0])
    u=np.array([1.0,0,0]) if abs(a@up)>0.999 else (up-(up@a)*a)
    u/=np.linalg.norm(u); v=np.cross(a,u); return np.column_stack([u,v,a])
def sph(th,ph): return np.array([np.sin(th)*np.cos(ph),np.sin(th)*np.sin(ph),np.cos(th)])
def ang(a,b): return np.arccos(np.clip(a@b,-1,1))
def childpsi(pa,psia,za,b,zb,Ro):
    n=np.cross(pa,b); n/=np.linalg.norm(n); da=np.arcsin(za*m/2/Ro)
    c=rot(n,pa,da); ca=frame(pa).T@c; cb=frame(b).T@c
    p_a=2*np.pi/za; p_b=2*np.pi/zb
    f=((np.arctan2(ca[1],ca[0])-psia)/p_a+0.5)%1-0.5
    return np.arctan2(cb[1],cb[0])+f*p_b-0.5*p_b
def evaluate(N,zC,zA,zB,Ro):
    dC,dA,dB=[np.arcsin(z*m/2/Ro) for z in (zC,zA,zB)]
    tip=m/Ro*1.0
    thA=dC+dA
    A=[sph(thA,2*np.pi*k/N) for k in range(N)]
    # B on mirror plane at azimuth pi/N, angle to A0 = dA+dB
    ph=np.pi/N; target=dA+dB
    # solve thB by bisection on angle(B,A0)
    lo,hi=thA, np.radians(140)
    f=lambda th: ang(sph(th,ph),A[0])-target
    if f(lo)>0 or f(hi)<0: return None
    for _ in range(60):
        mid=(lo+hi)/2
        if f(mid)<0: lo=mid
        else: hi=mid
    thB=(lo+hi)/2; B0=sph(thB,ph); B1=sph(thB,ph+2*np.pi/N)
    gAA=ang(A[0],A[1])-2*dA-2*tip
    gBB=ang(B0,B1)-2*dB-2*tip
    gBC=ang(B0,np.array([0,0,1.0]))-dB-dC-2*tip
    C=np.array([0,0,1.0])
    psiA0=childpsi(C,0.0,zC,A[0],zA,Ro); psiA1=childpsi(C,0.0,zC,A[1],zA,Ro)
    pB1=childpsi(A[0],psiA0,zA,B0,zB,Ro); pB2=childpsi(A[1],psiA1,zA,B0,zB,Ro)
    mis=((pB1-pB2)/(2*np.pi/zB)+0.5)%1-0.5
    return dict(thA=np.degrees(thA),thB=np.degrees(thB),low=np.degrees(thB+dB),gAA=np.degrees(gAA),gBB=np.degrees(gBB),gBC=np.degrees(gBC),mis=mis,dA=np.degrees(dA),dB=np.degrees(dB),dC=np.degrees(dC))
# --- search (slow; narrow the ranges) ---
res=[]
for N in (5,6):
  for zC in range(N*3,N*8,N):
    for zA in range(12,22):
      for zB in range(12,24):
        for Ro in np.arange(40,70,0.05):
          r=evaluate(N,zC,zA,zB,Ro)
          if r is None: continue
          if min(r['gAA'],r['gBB'],r['gBC'])<1.0: continue
          if r['low']>108: continue
          if abs(r['mis'])<0.01: res.append((N,zC,zA,zB,round(Ro,2),{k:round(v,3) for k,v in r.items()}))
print(len(res))
# keep best per (N,zC,zA,zB): closest gaps small (dense) but >=1.5deg
import collections
best=collections.OrderedDict()
for x in res:
    key=x[:4]; g=min(x[5]['gAA'],x[5]['gBB'])
    if key not in best or abs(x[5]['mis'])<abs(best[key][5]['mis']): best[key]=x
for k,x in list(best.items())[:80]: print(x)
