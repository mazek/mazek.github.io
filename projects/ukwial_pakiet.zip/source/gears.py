import numpy as np, manifold3d as mf
from manifold3d import Manifold, Mesh, CrossSection

def inv(a): return np.tan(a)-a

def tooth_ring(z, m, delta, Ro, backlash=0.25, pa=np.radians(20), pts_flank=10, pts_tip=4, pts_root=6):
    """Closed ring of 3D points on back cone at outer cone distance Ro (Tredgold approx), ordered CCW."""
    cd=np.cos(delta); sd=np.sin(delta)
    zv=z/cd; rv=zv*m/2; rb=rv*np.cos(pa); ra=rv+m; rf=rv-1.25*m
    tp=np.pi*m/2-backlash
    psi=tp/(2*rv)
    def hw(r):
        r=max(r,rb); ar=np.arccos(rb/r); return psi+inv(pa)-inv(ar)
    rstart=max(rb,rf)
    rs=np.linspace(rstart,ra,pts_flank)
    pitch=2*np.pi/zv
    pts=[]
    for j in range(z):
        c=j*pitch
        # root arc from previous tooth right side to this tooth left side
        prev_end=c-pitch+hw(rstart)+1e-3 if rf<rb else c-pitch+hw(rf)
        start=c-hw(rstart)-1e-3 if rf<rb else c-hw(rf)
        for t in np.linspace(prev_end,start,pts_root)[1:]:
            pts.append((rf,t))
        for r in rs: pts.append((r,c-hw(r)))
        for t in np.linspace(c-hw(ra),c+hw(ra),pts_tip)[1:-1]: pts.append((ra,t))
        for r in rs[::-1]: pts.append((r,c+hw(r)))
    P=[]
    for rho,phv in pts:
        phi=phv/cd
        R=rho*cd; zz=Ro/cd-rho*sd
        P.append((R*np.cos(phi),R*np.sin(phi),zz))
    return np.array(P)

def loft_toward_apex(P, k):
    """Solid between ring P (outer) and k*P (inner), fan-capped. Lines through origin."""
    n=len(P); I=P*k
    ct=np.array([0,0,P[:,2].max()+0.05]); cb=np.array([0,0,I[:,2].min()-0.05])
    V=np.vstack([P,I,ct,cb]); it=2*n; ib=2*n+1
    T=[]
    for j in range(n):
        j2=(j+1)%n
        T.append((it,j,j2))
        T.append((ib,n+j2,n+j))
        T.append((j,n+j,n+j2))
        T.append((j,n+j2,j2))
    T=np.array(T,dtype=np.uint32)
    man=Manifold(Mesh(vert_properties=V.astype(np.float32),tri_verts=T))
    if man.volume()<0 or man.status()!=mf.Error.NoError:
        man=Manifold(Mesh(vert_properties=V.astype(np.float32),tri_verts=T[:,::-1].copy()))
    assert man.status()==mf.Error.NoError, man.status()
    return man

def bevel_toothed(z,m,delta,Ro,Ri,backlash=0.25):
    P=tooth_ring(z,m,delta,Ro,backlash)
    return loft_toward_apex(P,Ri/Ro)

if __name__=="__main__":
    g=bevel_toothed(16,2,np.arcsin(16/52),52,37)
    print(g.volume(), g.bounding_box(), g.status())
