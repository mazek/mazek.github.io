import numpy as np, manifold3d as mf
from manifold3d import Manifold, CrossSection
from gears import bevel_toothed
D2R=np.pi/180
SEG=64
# ---------------- global parameters ----------------
# Tight network: C (24 t) -> 6x A (15 t) -> 6x B (24 t), every B meshes with TWO A gears.
# RO solved numerically (layout_solver.py) so tooth phase matches around every C-A-B-A loop.
m=2.0; RO=57.8457; RI=RO-15.0; BL=0.20
zC=24; zA=15; zB=24; N=6
dA=np.arcsin(zA*m/2/RO); dB=np.arcsin(zB*m/2/RO); dC=np.arcsin(zC*m/2/RO)
H_O=16.0            # sphere centre O above lid top
LID_T=3.0; BASE_H=44.0; BASE_R=58.0; WALL=2.4; FLOOR=2.4
R_IN=BASE_R-WALL
DOME_R=36.0; DOME_IN=33.6; SKIRT_R=40.0
SCREW_R=52.0; SCREW_ANG=[90,210,330]
# Hub / axle stack in gear-local z (= distance from O along axis)
HUB_PROT=6.0; SLOT_W=5.4; SLOT_D=6.0; ARM_T=5.0
INS_D=4.1; INS_DEPTH=7.0

def cyl(h,r,z0=0,seg=SEG,r2=None):
    return Manifold.cylinder(h,r,r if r2 is None else r2,seg).translate([0,0,z0])
def box(x0,x1,y0,y1,z0,z1):
    return Manifold.cube([x1-x0,y1-y0,z1-z0]).translate([x0,y0,z0])
def hexprism(af,h,z0=0):
    r=af/(2*np.cos(np.pi/6))
    return CrossSection.circle(r,6).rotate(30).extrude(h).translate([0,0,z0])
def frame(a):
    a=np.asarray(a,float); a/=np.linalg.norm(a)
    up=np.array([0,0,1.0])
    if abs(a@up)>0.999: u=np.array([1.0,0,0])
    else:
        u=up-(up@a)*a; u/=np.linalg.norm(u)
    v=np.cross(a,u)
    return np.column_stack([u,v,a])
def place(man,a,origin=(0,0,0)):
    R=frame(a); M=np.hstack([R,np.array(origin,float).reshape(3,1)])
    return man.transform(M)
def rot(axis,v,t):
    axis=np.asarray(axis,float); axis/=np.linalg.norm(axis)
    return v*np.cos(t)+np.cross(axis,v)*np.sin(t)+axis*(axis@v)*(1-np.cos(t))

# ---------------- gear axes ----------------
def axes():
    C=np.array([0,0,1.0]); thA=dC+dA
    sph=lambda th,ph: np.array([np.sin(th)*np.cos(ph),np.sin(th)*np.sin(ph),np.cos(th)])
    A=[sph(thA,2*np.pi*k/N) for k in range(N)]
    ph=np.pi/N; lo,hi=thA,140*D2R
    for _ in range(80):                      # B on the symmetry plane, tangent to A0 and A1
        mid=(lo+hi)/2
        if np.arccos(np.clip(sph(mid,ph)@A[0],-1,1))<dA+dB: lo=mid
        else: hi=mid
    B=[sph(mid,ph+2*np.pi*k/N) for k in range(N)]
    return C,A,B

# ---------------- gear stack heights ----------------
def stack(delta,hub_r):
    zf=RI*np.cos(delta)                       # flat inner face
    zb=RO*np.cos(delta)+1.25*m*np.sin(delta)  # back (root at outer end)
    zh1=zb+HUB_PROT
    zs=zh1-SLOT_D
    zr=zb-4.5
    return dict(zf=zf,zb=zb,zh1=zh1,zs=zs,zr=zr,boss=zf-0.4)
SA=stack(dA,8); SB=stack(dB,9); SC=stack(dC,9)

def toothed(z,delta,Ro=RO,Ri=RI,mm=m):
    T=bevel_toothed(z,mm,delta,Ro,Ri,BL)
    zf=Ri*np.cos(delta)
    return T ^ cyl(100,100,zf)

def gear_axle(z,delta,S,hub_r,pockets=0,pr=0,prr=0):
    g=toothed(z,delta)
    g=g+cyl(S['zh1']-S['zf'],hub_r,S['zf'])
    g=g-cyl(S['zr']-S['zf']+2,3.2,S['zf']-1)             # 6.4 mm bore for the sleeve
    g=g-cyl(S['zh1']-S['zr']+1,4.75,S['zr'])              # recess for washer and screw head
    g=g-box(-12,12,-SLOT_W/2,SLOT_W/2,S['zs'],S['zh1']+1)  # slot for the leaf tab
    for k in range(pockets):
        a=(k*360/pockets+180/pockets)*D2R
        g=g-cyl(20,pr,S['zb']-4.0,32).translate([prr*np.cos(a),prr*np.sin(a),0])
    return g
def gearA(): return gear_axle(zA,dA,SA,8.0)
def gearB(): return gear_axle(zB,dB,SB,9.0,8,3.2,17.0)

def gearC():
    S=SC; g=toothed(zC,dC)
    g=g+cyl(S['zh1']-S['zf'],9.0,S['zf'])
    g=g-hexprism(6.25,(S['zs']-1.5)-S['zf']+1,S['zf']-1)  # hex drive socket from below
    g=g-box(-11,11,-SLOT_W/2,SLOT_W/2,S['zs'],S['zh1']+1)
    for k in range(8):
        a=(k*45+22.5)*D2R
        g=g-cyl(20,3.2,S['zb']-4.0,32).translate([17*np.cos(a),17*np.sin(a),0])
    return g

# miter pair for the crank drive
MZ=16; MM=2.0; MRO=MZ*MM/2/np.sin(np.pi/4); MRI=16.0
def miter(hub_top):
    d=np.pi/4; zf=MRI*np.cos(d)
    g=toothed(MZ,d,MRO,MRI,MM)
    g=g+cyl(hub_top-zf,8.0,zf)
    g=g-hexprism(6.2,hub_top-zf+2,zf-1)
    return g
MITER_ZB=MRO*np.cos(np.pi/4)+1.25*MM*np.sin(np.pi/4)
M_ZF=MRI*np.cos(np.pi/4)

# ---------------- small parts ----------------
def sleeve(S):
    L=(S['zr']+0.4)-S['boss']
    return cyl(L,3.0)-cyl(L+2,1.65,-1), L
POLE_WALL=2.0
COUPLER_L=(SC['zs']-1.5-0.4)-(SC['boss']+0.2)   # set against the pole over a sheet of paper
def coupler():   # N20 3 mm D-shaft -> 6 mm hex
    c=hexprism(6.0,COUPLER_L)
    d=(CrossSection.circle(1.55,40) ^ CrossSection.square([3.2,2.55],center=False).translate([-1.6,-1.55])).extrude(COUPLER_L+2).translate([0,0,-1])
    return c-d
def hex_shaft(L):  # printed lying on a flat face
    r=6.0/(2*np.cos(np.pi/6))
    return CrossSection.circle(r,6).extrude(L).rotate([90,0,0])

# ---------------- top (lid + dome) ----------------
def top(version):
    C,A,B=axes(); zl=-H_O
    lid=cyl(LID_T,BASE_R,zl-LID_T,128)
    sph=Manifold.sphere(DOME_R,128)
    outer=Manifold.batch_hull([sph, cyl(0.01,SKIRT_R,zl,128)]) ^ cyl(200,100,zl)
    cav_s=Manifold.sphere(DOME_IN,96)
    cav=Manifold.batch_hull([cav_s, cyl(0.01,SKIRT_R-2.4,zl-0.5,128)]) ^ cyl(200,100,zl-1)
    ap=DOME_IN*np.sqrt(2)
    cone=Manifold.cylinder(ap-(zl-1),ap-(zl-1),0,128).translate([0,0,zl-1])  # 45-degree ceiling, no supports needed
    cav=cav ^ cone
    body=lid+(outer-cav)
    # bosses
    bosses=[]; holes=[]
    for a,S in [(x,SA) for x in A]+[(x,SB) for x in B]:
        L1=S['boss']; L0=L1-11.0
        bosses.append(place(cyl(L1-L0,6.0,L0),a))
        holes.append(place(cyl(INS_DEPTH+0.01,INS_D/2,L1-INS_DEPTH),a))
    # pole
    bosses.append(cyl(SC['boss']-26,8.0,26))
    body=body+Manifold.batch_boolean(bosses,mf.OpType.Add)
    body=body-Manifold.batch_boolean(holes,mf.OpType.Add)
    if version=='motor':
        zface=SC['boss']-POLE_WALL
        tube=box(-8.2,8.2,-7.2,7.2,zl-LID_T,zface)
        pocket=box(-6.15,6.15,-5.15,5.15,zl-LID_T-1,zface)
        body=body+tube-pocket
        body=body-cyl(10,2.3,zface-1)                       # gearbox boss / shaft
        for s in (-4.5,4.5): body=body-cyl(10,0.85,zface-1,24).translate([s,0,0])  # M1.6 (verify on your N20)
    else:
        tube=cyl(SC['boss']-(zl-LID_T),7.0,zl-LID_T)
        body=body+tube-cyl(200,3.7,zl-LID_T-5)
    # countersunk lid screws
    for a in SCREW_ANG:
        x,y=SCREW_R*np.cos(a*D2R),SCREW_R*np.sin(a*D2R)
        body=body-cyl(20,1.7,zl-20).translate([x,y,0])-cyl(1.8,1.7,zl-1.8,SEG,r2=3.3).translate([x,y,0])
    return body

# ---------------- bases (z=0 table) ----------------
def base_shell():
    b=cyl(BASE_H,BASE_R,0,128)-cyl(BASE_H,R_IN,FLOOR,128)
    for a in SCREW_ANG:
        x,y=SCREW_R*np.cos(a*D2R),SCREW_R*np.sin(a*D2R)
        b=b+(cyl(BASE_H-FLOOR,4.5,FLOOR).translate([x,y,0]) ^ cyl(BASE_H,BASE_R-0.5,0,128))
        b=b-cyl(INS_DEPTH+0.01,INS_D/2,BASE_H-INS_DEPTH).translate([x,y,0])
    # rubber-foot recesses
    for a in (30,150,270):
        b=b-cyl(1.0,5.2,-0.01).translate([46*np.cos(a*D2R),46*np.sin(a*D2R),0])
    return b

def teardrop_x(r,L,x0):
    # 45-degree teardrop, tip ends up pointing +z after the rotation below
    cs=CrossSection.batch_hull([CrossSection.circle(r,48),CrossSection.square([r,r],center=True).rotate(45).translate([-0.7071*r,0])])
    # extrude along z then rotate so it runs along +x, tip pointing +z
    return cs.extrude(L).rotate([0,90,0]).translate([x0,0,0])

ZQ=22.0
def base_crank():
    b=base_shell()
    # floor bearing post for vertical shaft
    b=b+cyl(ZQ-5-FLOOR,7.0,FLOOR)-cyl(30,3.7,FLOOR+1.0)
    # pillow block for horizontal shaft
    pb=box(24,R_IN+0.5,-9,9,FLOOR,ZQ)+cyl(R_IN+0.5-24,9,0).rotate([0,90,0]).translate([24,0,ZQ])
    pb=pb ^ cyl(BASE_H,R_IN+1,0,128)
    b=b+pb
    td=teardrop_x(3.75,80,0).translate([0,0,ZQ])
    b=b-td
    return b

def base_motor(pwm):
    b=base_shell()
    # TP4056 rails (USB-C to +x wall)
    for s in (1,-1):
        r=box(26,54.5,8.0 if s>0 else -10.5,10.5 if s>0 else -8.0,FLOOR,9.5)
        g=box(25,56,8.0-0.1 if s>0 else -9.05,9.05 if s>0 else -7.9,5.4,7.4)
        b=b+(r ^ cyl(BASE_H,R_IN+0.5,0,128))-g
    # USB-C slot
    slot=box(50,62,-5.5,5.5,6.6,11.4)
    b=b-slot
    # rocker switch cut-out on -x wall (KCD11, verify 9.2 x 13.4)
    b=b-box(-62,-50,-4.6,4.6,23-6.7,23+6.7)
    # 18650 holder cradle (78 x 22 footprint)
    cr=box(-40.5,40.5,12.0,36.0,FLOOR,FLOOR+3)-box(-39.2,39.2,13.3,34.7,FLOOR,FLOOR+4)
    b=b+(cr ^ cyl(BASE_H,R_IN+0.5,0,128))
    if pwm:
        b=b-cyl(20,3.6,0).rotate([90,0,0]).translate([0,-50,24])   # 7.2 mm hole for panel pot / button, -y wall
    return b

# ---------------- crank parts ----------------
def crank_wheel():
    w=cyl(6.0,18.0,0,96)+cyl(8.0,8.5,6.0)
    w=w-hexprism(6.25,9.0,5.0)            # socket from the hub side
    w=w-cyl(12,1.3,-4,24).translate([12,0,0])   # M3 self-tap 2.6 for knob screw
    # grip notches
    for k in range(24):
        a=k*15*D2R; w=w-cyl(8,1.2,-1,16).translate([18.6*np.cos(a),18.6*np.sin(a),0])
    return w
def crank_knob():
    return cyl(18,5.0,0,48)-cyl(20,1.75,-1,24)-cyl(3.2,3.0,15,32)

# ---------------- arms ----------------
def catmull(P,n=200):
    P=np.asarray(P,float); P=np.vstack([P[0],P,P[-1]])
    out=[]
    for i in range(1,len(P)-2):
        p0,p1,p2,p3=P[i-1],P[i],P[i+1],P[i+2]
        for t in np.linspace(0,1,n//(len(P)-3),endpoint=False):
            out.append(0.5*((2*p1)+(-p0+p2)*t+(2*p0-5*p1+4*p2-p3)*t*t+(-p0+3*p1-3*p2+p3)*t**3))
    out.append(P[-2]); return np.array(out)

def arm_from_curve(pts,w0,w1,ball,tab_w,stack_,cone_deg):
    """pts: (r,L) centreline in the arm plane (x=r, z=L). Returns Manifold with tab, thickness ARM_T in y."""
    zs,zh1=stack_['zs'],stack_['zh1']
    n=len(pts); circles=[]
    lim=np.tan(cone_deg*D2R)
    for i,(r,L) in enumerate(pts):
        w=w0+(w1-w0)*(i/(n-1))**0.8
        circles.append((r,L,w/2))
    # enforce cone: shrink r if needed
    cs=[]
    for (r,L,h) in circles:
        rmax=np.sqrt(max((L*lim)**2-(ARM_T/2)**2,0))-h-0.3
        r=np.clip(r,-rmax,rmax)
        cs.append(CrossSection.circle(h,24).translate([r,L]))
    rb,Lb,_=circles[-1]
    rmaxb=np.sqrt(max((Lb*lim)**2-(ARM_T/2)**2,0))-ball-0.3
    rb=np.clip(rb,-rmaxb,rmaxb)
    parts=[CrossSection.batch_hull([cs[i],cs[i+1]]) for i in range(len(cs)-1)]
    parts.append(CrossSection.circle(ball,40).translate([rb,Lb]))
    tab=CrossSection.square([tab_w,zh1-zs+0.01]).translate([-tab_w/2,zs])
    collar=CrossSection.batch_hull([CrossSection.square([tab_w,1.0]).translate([-tab_w/2,zh1-0.5]),cs[3]])
    parts+= [tab,collar]
    sec=CrossSection.batch_boolean(parts,mf.OpType.Add)
    # sec lives in (x=r, y=L); extrude in local z -> rotate so L->z and thickness->y
    man=sec.extrude(ARM_T).translate([0,0,-ARM_T/2]).rotate([90,0,0])  # (x,y,z)->(x,-z,y)
    return man, sec

def arm_A():   # (legacy) wavy arm for the 15-tooth gears
    zh=SA['zh1']; cone=np.degrees(dA)-2.0; lim=np.tan(cone*D2R)
    L=np.linspace(zh,135,9); s=(L-zh)/(135-zh)
    r=np.sin(1.6*np.pi*s)*(L*lim)*0.8
    r[0]=0; r[1]*=0.4
    pts=catmull(np.column_stack([r,L]),240)
    return arm_from_curve(pts,7.5,3.0,3.2,2*8.0-0.6,SA,cone)

def arm_B():   # (legacy) hook arm for the 24-tooth gears
    zh=SB['zh1']; cone=np.degrees(dB)-2.0
    P=[(0,zh),(4,zh+8),(14,zh+22),(26,zh+42),(33,zh+62),(29,zh+78),(16,zh+84),(9,zh+75),(15,zh+67)]
    pts=catmull(P,260)
    return arm_from_curve(pts,9.0,3.4,3.4,2*9.0-0.6,SB,cone)

def topper():  # (legacy) spiral topper for the central gear
    zh=SC['zh1']; cone=np.degrees(dC)-2.0
    P=[(0,zh),(0,zh+8),(-3,zh+18),(4,zh+28),(15,zh+30),(20,zh+22),(15,zh+14),(8,zh+20),(11,zh+25)]
    pts=catmull(P,220)
    return arm_from_curve(pts,8.0,3.4,3.0,2*9.0-0.6,SC,cone)

# ---------------- leaves (wide, concave shells) ----------------
LEAF_T=1.8          # leaf blade thickness
def _shell(top,bot):
    """Closed mesh from two surfaces [S,U,3] (blade between them)."""
    S,U,_=top.shape; V=np.vstack([top.reshape(-1,3),bot.reshape(-1,3)]); n=S*U
    idx=lambda i,j,b=0: b*n+i*U+j
    T=[]
    for i in range(S-1):
        for j in range(U-1):
            a,b_,c,d=idx(i,j),idx(i+1,j),idx(i+1,j+1),idx(i,j+1)
            T+=[(a,b_,c),(a,c,d)]
            a,b_,c,d=idx(i,j,1),idx(i+1,j,1),idx(i+1,j+1,1),idx(i,j+1,1)
            T+=[(a,c,b_),(a,d,c)]
    for i in range(S-1):            # side edges
        for j in (0,U-1):
            a,b_,c,d=idx(i,j),idx(i+1,j),idx(i+1,j,1),idx(i,j,1)
            T+= [(a,c,b_),(a,d,c)] if j==0 else [(a,b_,c),(a,c,d)]
    for i in (0,S-1):               # base and tip
        for j in range(U-1):
            a,b_,c,d=idx(i,j),idx(i,j+1),idx(i,j+1,1),idx(i,j,1)
            T+= [(a,b_,c),(a,c,d)] if i==0 else [(a,c,b_),(a,d,c)]
    T=np.array(T,dtype=np.uint32)
    for tri in (T,T[:,::-1].copy()):
        man=Manifold(mf.Mesh(vert_properties=V.astype(np.float32),tri_verts=tri))
        if man.status()==mf.Error.NoError and man.volume()>0: return man
    raise RuntimeError('leaf mesh invalid')

def leaf(S_,cone_deg,L1,midrib,W,sag_frac=0.32,s_n=70,u_n=25,tab_hw=8.0,peak=1.3):
    """Leaf in the gear-axis plane (x=r, z=L), concave towards -y.
    The +y side (y=2.5) is flat along the midrib and sits on the print bed."""
    zh,zs=S_['zh1'],S_['zs']
    lim=np.tan(cone_deg*D2R)
    s=np.linspace(0,1,s_n); L0=zh+2.0
    Lc=L0+(L1-L0)*s
    rm=np.array([midrib(x) for x in s])
    P=np.column_stack([rm,Lc])
    T=np.gradient(P,axis=0); T/=np.linalg.norm(T,axis=1,keepdims=True)
    Nn=np.column_stack([T[:,1],-T[:,0]])
    # leaf outline: stalk, then a wide blade narrowing to a sharp tip
    x=np.clip((s-0.10)/0.90,0,1)
    w=np.maximum(4.0*(1-s)+0.6, W*np.sin(np.pi*x**peak)**0.85)
    w[-1]=0.6
    u=np.linspace(-1,1,u_n)
    def build(w):
        sag=sag_frac*w*np.clip(s/0.25,0,1)
        u0=0.12
        prof=np.clip((np.abs(u)-u0)/(1-u0),0,1)**2
        yo=2.5-sag[:,None]*prof[None,:]
        yi=yo-LEAF_T-np.clip((0.2-s)/0.2,0,1)[:,None]*(5.0-LEAF_T)*(1-prof[None,:])
        xy=P[:,None,:]+(w[:,None,None]*u[None,:,None])*Nn[:,None,:]
        top=np.dstack([xy[:,:,0],yo,xy[:,:,1]]); bot=np.dstack([xy[:,:,0],yi,xy[:,:,1]])
        return top,bot
    def fits(wt):
        top,bot=build(wt)
        for G in (top,bot):
            d=np.hypot(G[:,:,0],G[:,:,1])
            if (d>G[:,:,2]*lim-0.6).any(): return False
        return True
    lo,hi=0.2,1.0                 # one scale factor for the whole leaf -> smooth outline
    if fits(w): lo=1.0
    else:
        for _ in range(30):
            k=(lo+hi)/2
            if fits(w*k): lo=k
            else: hi=k
    w=w*lo
    leaf.last_scale=lo
    top,bot=build(w)
    blade=_shell(top,bot)
    tab=CrossSection.square([2*tab_hw-0.6,zh-zs+0.01]).translate([-(tab_hw-0.3),zs])
    stem=CrossSection.batch_hull([CrossSection.square([2*tab_hw-0.6,1.0]).translate([-(tab_hw-0.3),zh-0.5]),
                                  CrossSection.circle(4.0,24).translate([rm[0],L0+3])])
    flat=CrossSection.batch_boolean([tab,stem],mf.OpType.Add).extrude(5.0).translate([0,0,-2.5]).rotate([90,0,0])
    return blade+flat

def leaf_A():  # slender leaf for the small gears (13° cone)
    return leaf(SA,np.degrees(dA)-2.5,142,lambda x:2.5*np.sin(np.pi*x),W=24,sag_frac=0.30)
def leaf_B():  # wide leaf for the large gears (22° cone)
    return leaf(SB,np.degrees(dB)-2.5,152,lambda x:5*np.sin(np.pi*x),W=40,sag_frac=0.32)
def leaf_C():  # crown leaf on the central gear
    return leaf(SC,np.degrees(dC)-2.5,122,lambda x:-3*np.sin(np.pi*x),W=28,sag_frac=0.30,tab_hw=9.0)
