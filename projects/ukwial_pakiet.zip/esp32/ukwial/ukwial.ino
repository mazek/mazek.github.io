// Ukwiał – kinetic sculpture controller
// ESP32-C3 SuperMini + DRV8833 + N20 motor, powered by 1x18650 (via protected TP4056)
// Arduino-ESP32 core 3.x (ledcAttach / ledcWrite)
//
// Button (GPIO5 -> GND):
//   short press        – next mode
//   long press (>1.2 s) – smooth stop and deep sleep (wake: button)
// Modes: 0 slow, 1 medium, 2 "breathing" (undulating speed), 3 "pendulum" (reverses every 20 s)
// The mechanism can safely turn both ways – the leaves never collide.

#include <Arduino.h>
#include "esp_sleep.h"

const int PIN_IN1 = 3, PIN_IN2 = 4, PIN_EEP = 6, PIN_BTN = 5, PIN_VBAT = 0;
const uint32_t PWM_FREQ = 20000;   // above the audible range
const uint8_t  PWM_BITS = 10;      // 0..1023
const int DUTY_MIN = 380;          // below this an N20 usually stalls – tune for your motor
const int DUTY_MAX = 1023;
const uint32_t AUTO_SLEEP_MS = 30UL * 60UL * 1000UL;  // 30 min
const float VBAT_CUTOFF = 3.30;    // V, protects the cell (TP4056 only cuts off at ~2.4 V)

int mode = 0;
float current = 0;                 // current speed -1..1 (sign = direction)
uint32_t tStart, tModeStart;

float readVbat() {                 // 100k/100k divider
  uint32_t mv = 0;
  for (int i = 0; i < 8; i++) mv += analogReadMilliVolts(PIN_VBAT);
  return (mv / 8.0f) * 2.0f / 1000.0f;
}

void drive(float s) {              // s: -1..1
  int duty = 0;
  float a = fabsf(s);
  if (a > 0.02f) duty = DUTY_MIN + (int)((DUTY_MAX - DUTY_MIN) * a);
  if (s >= 0) { ledcWrite(PIN_IN1, duty); ledcWrite(PIN_IN2, 0); }
  else        { ledcWrite(PIN_IN1, 0);    ledcWrite(PIN_IN2, duty); }
}

float target(uint32_t now) {
  float t = (now - tModeStart) / 1000.0f;
  switch (mode) {
    case 0: return 0.15f;
    case 1: return 0.45f;
    case 2: return 0.30f + 0.25f * sinf(t * 2 * PI / 12.0f);          // breathing, 12 s period
    case 3: return ((int)(t / 20.0f) % 2 ? -0.30f : 0.30f);            // pendulum
  }
  return 0;
}

void goToSleep() {
  for (int i = 0; i < 100; i++) { current *= 0.95f; drive(current); delay(15); }
  drive(0);
  digitalWrite(PIN_EEP, LOW);
  while (digitalRead(PIN_BTN) == LOW) delay(10);   // wait for button release
  delay(200);
  esp_deep_sleep_enable_gpio_wakeup(1ULL << PIN_BTN, ESP_GPIO_WAKEUP_GPIO_LOW);
  esp_deep_sleep_start();
}

void setup() {
  pinMode(PIN_BTN, INPUT_PULLUP);
  pinMode(PIN_EEP, OUTPUT);
  digitalWrite(PIN_EEP, HIGH);
  ledcAttach(PIN_IN1, PWM_FREQ, PWM_BITS);
  ledcAttach(PIN_IN2, PWM_FREQ, PWM_BITS);
  analogReadResolution(12);
  tStart = tModeStart = millis();
}

void loop() {
  static uint32_t pressedAt = 0;
  static bool wasDown = false;
  uint32_t now = millis();

  bool down = digitalRead(PIN_BTN) == LOW;
  if (down && !wasDown) pressedAt = now;
  if (down && now - pressedAt > 1200) goToSleep();
  if (!down && wasDown && now - pressedAt > 40) {
    mode = (mode + 1) % 4; tModeStart = now; tStart = now;
  }
  wasDown = down;

  if (now - tStart > AUTO_SLEEP_MS) goToSleep();
  static uint32_t lastV = 0;
  if (now - lastV > 5000) { lastV = now; if (readVbat() < VBAT_CUTOFF) goToSleep(); }

  // gentle ramp: max ~0.4 speed change per second – easy on the teeth
  float tg = target(now);
  float step = 0.4f * 0.02f;
  if (tg > current + step) current += step; else if (tg < current - step) current -= step; else current = tg;
  drive(current);
  delay(20);
}
