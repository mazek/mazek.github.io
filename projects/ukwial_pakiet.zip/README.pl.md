# Ukwiał — rzeźba kinetyczna do druku 3D

13 stożkowych kół zębatych zazębionych w jedną zwartą kulę — jedno koło napędza wszystkie pozostałe — każde z szerokim, wklęsłym liściem. Cztery wersje napędu: **Korbka**, **Silnik** (N20 + wyłącznik), **Regulator** (+ moduł PWM), **ESP32** (ESP32-C3 + DRV8833).

Interaktywny, animowany model i pełna instrukcja: https://www.marcinmazurek.com/projects/ukwial.html (przełącznik EN/PL). Podgląd: `preview.png`, `preview_gears.png`. English version: `README.md`.

## Zasada
- Osie wszystkich kół przechodzą przez środek kuli w kopule → każde koło jest stożkowe i zazębia się z sąsiadem pod dowolnym kątem.
- Koło centralne 24 z → 6 małych kół 15 z → 6 dużych kół 24 z, każde duże zazębione z DWOMA małymi. Razem 24 zazębienia w jednej siatce.
- Siatka ma zamknięte pętle C–A–B–A; promień stożków RO = 57,85 mm dobrany numerycznie (`source/layout_solver.py`), by faza zębów w każdej pętli zgadzała się co do zera. Koła, które nie mają się stykać, mają ~3 mm odstępu wierzchołków.
- Każdy liść leży wewnątrz stożka podziałowego swojego koła (generator skaluje go do stożka z zapasem 0,6 mm); stożki sąsiadów tylko się stykają → liście nie mogą się zderzyć przy żadnym kącie ani kierunku obrotu.
- Moduł 2, rozpiętość ≈ 29 cm, wysokość ≈ 19 cm, podstawa Ø116 mm, ≈ 280 g filamentu.

## Pliki STL (`stl/`, w orientacji do druku)
| Plik | Szt. | Wersje | Wymiary [mm] | Uwagi |
|---|---|---|---|---|
| `01_gear15_ring_A_x6.stl` | 6 | wszystkie | 34×34×21 | małe koła, płaską stroną w dół, 4 obrysy |
| `02_gear24_ring_B_x6.stl` | 6 | wszystkie | 52×52×21 | duże koła, każde między dwoma małymi |
| `03_gear24_center_x1.stl` | 1 | wszystkie | 52×52×21 | koło centralne, gniazdo hex 6 od spodu |
| `04_leaf_A_small_x6.stl` | 6 | wszystkie | 42×86×8 | smukłe liście do małych kół |
| `05_leaf_B_large_x6.stl` | 6 | wszystkie | 79×98×14 | szerokie liście do dużych kół |
| `06_leaf_crown_x1.stl` | 1 | wszystkie | 56×68×10 | liść korony na koło centralne |
| `07_sleeve_A_11.4mm_x6.stl` | 6 | wszystkie | 6×6×11 | tuleje osi małych kół, pionowo |
| `08_sleeve_B_11.0mm_x6.stl` | 6 | wszystkie | 6×6×11 | tuleje osi dużych kół — nie mylić z A |
| `10_top_motor.stl` | 1 | Silnik, Regulator, ESP32 | 116×116×58 | kopuła z kieszenią N20; podpory pod dolne tulejki |
| `11_base_motor_switch.stl` | 1 | Silnik | 116×116×44 | USB-C, wyłącznik, koszyk 18650 |
| `12_base_motor_pwm_esp32.stl` | 1 | Regulator, ESP32 | 116×116×44 | j.w. + otwór Ø7,2 na pokrętło/przycisk |
| `13_coupler_N20_to_hex6.stl` | 1 | Silnik, Regulator, ESP32 | 6×7×13 | sprzęgło wałek D 3 mm → hex 6 |
| `20_top_crank.stl` | 1 | Korbka | 116×116×58 | kopuła z rurką łożyskową |
| `21_base_crank.stl` | 1 | Korbka | 116×116×44 | gniazdo wałka i blok łożyskowy |
| `22_miter_vertical.stl` | 1 | Korbka | 35×35×10 | koło stożkowe 16 z, pionowe |
| `23_miter_horizontal.stl` | 1 | Korbka | 35×35×12 | koło stożkowe 16 z, poziome (dłuższa piasta) |
| `24_shaft_vertical_hex6.stl` | 1 | Korbka | 7×111×6 | 111,3 mm, płasko na ściance, 100 % |
| `25_shaft_crank_hex6.stl` | 1 | Korbka | 7×56×6 | 55,5 mm, płasko, 100 % |
| `26_crank_wheel.stl` | 1 | Korbka | 36×36×14 | kółko Ø36, piastą do góry |
| `27_crank_knob.stl` | 1 | Korbka | 10×10×18 | gałka obraca się na śrubie M3 |

**Druk:** PLA/PETG, dysza 0,4, warstwa 0,16–0,2. Koła: 4 obrysy, 30 % gyroid. Liście: 3 obrysy, płaską stroną nerwu na stole, wklęsłością do góry; skrzydła ~60° od pionu — przy słabym chłodzeniu podpory drzewiaste od stołu. Wałki hex: 100 % (lub pręt aluminiowy hex 6). Podstawy bez podpór. Kopuła: podpory drzewiaste tylko pod sześcioma dolnymi tulejkami. Najpierw wydrukuj koło centralne, dwa małe i jedno duże i sprawdź, czy duże wchodzi między dwa małe.

## Elektronika (`wiring/pl/`, wersje angielskie w `wiring/`)
1. **Silnik + wyłącznik:** 18650 → TP4056 (B+/B−) → OUT+ → PTC 0,3 A → KCD11 → silnik; OUT− → silnik.
2. **Regulator:** jak wyżej, ale wyłącznik → VCC+ regulatora PWM, OUT+/OUT− regulatora → silnik. Opcja: potencjometr panelowy WH148 w otworze Ø7,2.
3. **ESP32:** V+ po wyłączniku → pin 5V ESP32-C3 i VM DRV8833; GPIO3→IN1, GPIO4→IN2, GPIO6→EEP, przycisk GPIO5↔GND, dzielnik 100k/100k z V+ na GPIO0. Szkic: `esp32/ukwial/ukwial.ino` (Arduino-ESP32 3.x).

N20 na 3,7 V daje ok. 60 % prędkości znamionowej: bez regulatora 30 obr/min, z regulatorem/ESP32 60–100 obr/min. Pobór 60–120 mA → 20–30 h na ogniwie 2500 mAh. PTC chroni też zęby przy zablokowaniu.

## Zakupy
| Element | Ilość | Wersje | Uwagi |
|---|---|---|---|
| Śruby M3×18 z łbem walcowym (DIN 912) | 12 | wszystkie | osie kół |
| Podkładki M3 (DIN 125) | 12 (+1) | wszystkie | +1 pod gałkę korbki |
| Wkładki gwintowane M3 do wtapiania (dł. 5,7, Ø 4,6) | 15 | wszystkie | 12 w kopule, 3 w podstawie; otwór 4,1 mm |
| Śruby M3×10 z łbem stożkowym (ISO 10642) | 3 | wszystkie | kopuła → podstawa |
| Nóżki gumowe samoprzylepne Ø10 | 3 | wszystkie | w zagłębienia w dnie |
| Klej CA (cyjanoakrylowy) | — | wszystkie | liście (opcja), koła na wałkach |
| Śruba M3×25 | 1 | Korbka | oś gałki |
| Silnik N20 6 V z przekładnią, wałek D 3 mm | 1 | Silnik, Regulator, ESP32 | 30 obr/min bez regulatora; 60–100 z regulatorem/ESP32 |
| Śruby M1,6×4 | 2 | Silnik, Regulator, ESP32 | opcja, mocowanie N20 (rozstaw 9 mm — sprawdź) |
| Ogniwo 18650 z zabezpieczeniem + koszyk 1×18650 | 1 | Silnik, Regulator, ESP32 | koszyk ok. 77×21 mm |
| Moduł ładowarki TP4056 USB-C z ochroną (6 pól) | 1 | Silnik, Regulator, ESP32 | ok. 28×17,5 mm; wersja z B+/B− i OUT+/OUT− |
| Przełącznik kołyskowy KCD11 (mini) | 1 | Silnik, Regulator, ESP32 | otwór 9,2×13,4 mm |
| Bezpiecznik polimerowy PTC 0,3 A (np. XF030) | 1 | Silnik, Regulator, ESP32 | w przewodzie + |
| Przewód 24–26 AWG, koszulki termokurczliwe | — | Silnik, Regulator, ESP32 |  |
| Kondensator ceramiczny 100 nF | 1 | Silnik, Regulator, ESP32 | opcja, na zaciskach silnika |
| Regulator PWM mini 5 A, 3–35 V | 1 | Regulator | opcja: potencjometr panelowy WH148 |
| ESP32-C3 SuperMini | 1 | ESP32 |  |
| Moduł DRV8833 | 1 | ESP32 | z wyprowadzonym EEP/nSLEEP |
| Przycisk chwilowy Ø7 mm (panelowy) | 1 | ESP32 | w otworze Ø7,2 |
| Rezystory 100 kΩ | 2 | ESP32 | dzielnik pomiaru ogniwa |

Zmierz swoje moduły (wyłącznik, TP4056, otwory w N20) — w razie różnic popraw wymiary w `source/parts.py`.

## Montaż
**Wspólne:** wtop 15 wkładek M3 (12 tulejek kopuły, 3 słupki podstawy).

**Silnik / Regulator / ESP32**
1. Przylutuj przewody do N20, wsuń go od spodu przez prostokątny otwór do kieszeni pod biegunem kopuły (opcjonalnie 2× M1,6×4 od góry lub klej na gorąco).
2. Wciśnij sprzęgło na wałek D, aż oprze się o biegun przez pasek papieru; papier wyjmij.
3. W podstawie: TP4056 w prowadnice (USB-C w szczelinę), wyłącznik w otwór, koszyk 18650 w ramkę; zlutuj wg schematu, PTC w przewodzie + w koszulce. Regulator/ESP32+DRV8833 na taśmie piankowej.
4. Test przed zamknięciem, potem kopuła na podstawę: 3× M3×10 stożkowe.

**Korbka**
1. Krótki wałek hex przez ścianę i blok łożyskowy; od środka koło poziome (płaską stroną do środka, wałek 0,2 mm schowany w kole), piasta oparta o blok — klej CA.
2. Koło pionowe na długim wałku (111,3 mm) płaską stroną w dół, 29,8 mm nad dolnym końcem wałka — klej. Wałek w gniazdo w dnie, zazębić.
3. Kopuła na wałek (przechodzi przez środkową rurkę), 3× M3×10.
4. Kółko na wałek (piastą do ściany, ~0,5 mm szczeliny), gałka na M3×25 z podkładką.

**Koła i liście (wszystkie wersje)**
1. Koło centralne na sprzęgło / wałek.
2. Małe koła (15 z): tuleja A (11,4 mm) w kole → koło na górną tulejkę, zazębić z centralnym → podkładka → M3×18 do oporu (śruba zaciska tuleję, koło kręci się swobodnie).
3. Duże koła (24 z): tuleja B (11,0 mm) → koło na dolną tulejkę między dwoma małymi, kołysać, aż wpadnie w oba → podkładka → M3×18. Przekręć bez liści — ma chodzić równo.
4. Liście: smukłe do małych kół, szerokie do dużych, liść korony do centralnego. Kąt dowolny. Ewentualnie kropla CA.

## Problemy
- Zacięcie w jednym miejscu obrotu → nadlew na zębie lub zamienione tuleje A/B; zdejmuj duże koła po jednym.
- Duże koło nie wchodzi → wkładki nierówno wtopione albo wydruk przeskalowany.
- Silnik buczy → więcej wypełnienia (pokrętło / `DUTY_MIN`), sprawdź ogniwo i PTC.
- Luz liści → parametr `BL` w `parts.py`.

## Źródła
`source/` — `pip install manifold3d trimesh numpy`, potem `python build_all.py`. Po zmianie liczby zębów przelicz RO skryptem `layout_solver.py`, inaczej siatka się zablokuje.

Inspiracja: prace @mechdesign98; geometria i wszystkie części zaprojektowane od nowa.
