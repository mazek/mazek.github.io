# Ukwiał — a 3D-printable kinetic sculpture

*Ukwiał* is Polish for “sea anemone”. Thirteen bevel gears meshed into one tight ball — one gear drives all the others — each carrying a wide, concave leaf. Four drive versions: **Crank**, **Motor** (N20 + switch), **Controller** (+ PWM module), **ESP32** (ESP32-C3 + DRV8833).

Interactive, animated model and full guide: https://www.marcinmazurek.com/projects/ukwial.html (EN/PL switch). Previews: `preview.png`, `preview_gears.png`. Polish version: `README.pl.md`.

## How it works
- Every gear axis passes through the centre of the sphere inside the dome → every gear is a bevel gear and meshes with its neighbour at any angle.
- Central gear 24 t → 6 small gears 15 t → 6 large gears 24 t, each large gear meshing with TWO small ones. 24 meshes in one network.
- The network has closed loops C–A–B–A; the cone radius RO = 57.85 mm was solved numerically (`source/layout_solver.py`) so the tooth phase around every loop matches exactly. Gears that must not touch keep ~3 mm between tooth tips.
- Every leaf lies inside its gear's pitch cone (the generator scales it to the cone with a 0.6 mm margin); neighbouring cones only touch → the leaves cannot collide at any angle or in either direction.
- Module 2, span ≈ 29 cm, height ≈ 19 cm, base Ø116 mm, ≈ 280 g of filament.

## STL files (`stl/`, already oriented for printing)
| File | Qty | Versions | Size [mm] | Notes |
|---|---|---|---|---|
| `01_gear15_ring_A_x6.stl` | 6 | all | 34×34×21 | small gears, flat side down, 4 walls |
| `02_gear24_ring_B_x6.stl` | 6 | all | 52×52×21 | large gears, each between two small ones |
| `03_gear24_center_x1.stl` | 1 | all | 52×52×21 | central gear, 6 mm hex socket underneath |
| `04_leaf_A_small_x6.stl` | 6 | all | 42×86×8 | slender leaves for the small gears |
| `05_leaf_B_large_x6.stl` | 6 | all | 79×98×14 | wide leaves for the large gears |
| `06_leaf_crown_x1.stl` | 1 | all | 56×68×10 | crown leaf for the central gear |
| `07_sleeve_A_11.4mm_x6.stl` | 6 | all | 6×6×11 | axle sleeves for the small gears, upright |
| `08_sleeve_B_11.0mm_x6.stl` | 6 | all | 6×6×11 | axle sleeves for the large gears — don't mix up with A |
| `10_top_motor.stl` | 1 | Motor, Controller, ESP32 | 116×116×58 | dome with N20 pocket; supports under the lower bosses |
| `11_base_motor_switch.stl` | 1 | Motor | 116×116×44 | USB-C, switch, 18650 holder |
| `12_base_motor_pwm_esp32.stl` | 1 | Controller, ESP32 | 116×116×44 | as above + Ø7.2 hole for knob/button |
| `13_coupler_N20_to_hex6.stl` | 1 | Motor, Controller, ESP32 | 6×7×13 | coupler: 3 mm D-shaft → 6 mm hex |
| `20_top_crank.stl` | 1 | Crank | 116×116×58 | dome with bearing tube |
| `21_base_crank.stl` | 1 | Crank | 116×116×44 | shaft socket and bearing block |
| `22_miter_vertical.stl` | 1 | Crank | 35×35×10 | 16-tooth bevel gear, vertical |
| `23_miter_horizontal.stl` | 1 | Crank | 35×35×12 | 16-tooth bevel gear, horizontal (longer hub) |
| `24_shaft_vertical_hex6.stl` | 1 | Crank | 7×111×6 | 111.3 mm, flat on a face, 100 % |
| `25_shaft_crank_hex6.stl` | 1 | Crank | 7×56×6 | 55.5 mm, flat, 100 % |
| `26_crank_wheel.stl` | 1 | Crank | 36×36×14 | Ø36 wheel, hub up |
| `27_crank_knob.stl` | 1 | Crank | 10×10×18 | knob spins on an M3 screw |

**Printing:** PLA/PETG, 0.4 nozzle, 0.16–0.2 layers. Gears: 4 walls, 30 % gyroid. Leaves: 3 walls, flat side of the midrib on the bed, concave side up; the wings rise up to ~60° from vertical — with weak cooling use tree supports from the build plate. Hex shafts: 100 % (or 6 mm aluminium hex rod). Bases need no supports. Dome: tree supports only under the six lower bosses. First print the central gear, two small ones and one large one, and check that the large gear drops in between the two small ones.

## Electronics (`wiring/`, Polish versions in `wiring/pl/`)
1. **Motor + switch:** 18650 → TP4056 (B+/B−) → OUT+ → PTC 0.3 A → KCD11 → motor; OUT− → motor.
2. **Controller:** as above, but switch → PWM controller VCC+, controller OUT+/OUT− → motor. Option: WH148 panel potentiometer in the Ø7.2 hole.
3. **ESP32:** V+ after the switch → ESP32-C3 5V pin and DRV8833 VM; GPIO3→IN1, GPIO4→IN2, GPIO6→EEP, button GPIO5↔GND, 100k/100k divider from V+ to GPIO0. Sketch: `esp32/ukwial/ukwial.ino` (Arduino-ESP32 3.x).

An N20 on 3.7 V runs at about 60 % of its rated speed: without a controller use 30 rpm, with the controller/ESP32 60–100 rpm. Draw 60–120 mA → 20–30 h on a 2500 mAh cell. The PTC also protects the teeth if the mechanism jams.

## Shopping list
| Item | Qty | Versions | Notes |
|---|---|---|---|
| M3×18 socket head screws (DIN 912) | 12 | all | gear axles |
| M3 washers (DIN 125) | 12 (+1) | all | +1 for the crank knob |
| M3 heat-set inserts (5.7 mm long, Ø4.6) | 15 | all | 12 in the dome, 3 in the base; 4.1 mm hole |
| M3×10 countersunk screws (ISO 10642) | 3 | all | dome → base |
| Ø10 self-adhesive rubber feet | 3 | all | into the recesses under the base |
| CA glue (superglue) | — | all | leaves (optional), gears on shafts |
| M3×25 screw | 1 | Crank | knob axle |
| N20 6 V gear motor, 3 mm D-shaft | 1 | Motor, Controller, ESP32 | 30 rpm without controller; 60–100 rpm with controller/ESP32 |
| M1.6×4 screws | 2 | Motor, Controller, ESP32 | optional, N20 mounting (9 mm spacing — check yours) |
| Protected 18650 cell + 1×18650 holder | 1 | Motor, Controller, ESP32 | holder approx. 77×21 mm |
| TP4056 USB-C charger module with protection (6 pads) | 1 | Motor, Controller, ESP32 | approx. 28×17.5 mm; version with B+/B− and OUT+/OUT− |
| KCD11 mini rocker switch | 1 | Motor, Controller, ESP32 | 9.2×13.4 mm cut-out |
| 0.3 A PTC polyfuse (e.g. XF030) | 1 | Motor, Controller, ESP32 | in the + lead |
| 24–26 AWG wire, heat-shrink tubing | — | Motor, Controller, ESP32 |  |
| 100 nF ceramic capacitor | 1 | Motor, Controller, ESP32 | optional, across the motor terminals |
| Mini PWM motor controller 5 A, 3–35 V | 1 | Controller | option: WH148 panel potentiometer |
| ESP32-C3 SuperMini | 1 | ESP32 |  |
| DRV8833 module | 1 | ESP32 | with EEP/nSLEEP broken out |
| Ø7 mm momentary panel push button | 1 | ESP32 | in the Ø7.2 hole |
| 100 kΩ resistors | 2 | ESP32 | cell-voltage divider |

Measure your modules (switch, TP4056, N20 holes) — if they differ, adjust the dimensions in `source/parts.py`.

## Assembly
**Common:** set 15 M3 heat-set inserts (12 dome bosses, 3 base posts).

**Motor / Controller / ESP32**
1. Solder leads to the N20 and slide it in from below through the rectangular opening into the pocket under the pole of the dome (optionally 2× M1.6×4 from above, or hot glue).
2. Press the coupler onto the D-shaft until it rests on the pole over a strip of paper; remove the paper.
3. In the base: TP4056 into the rails (USB-C into the slot), switch into its hole, 18650 holder into the frame; wire per diagram, PTC in the + lead under heat-shrink. Controller/ESP32+DRV8833 on foam tape.
4. Test before closing, then dome onto the base: 3× M3×10 countersunk.

**Crank**
1. Short hex shaft through the wall and bearing block; from the inside the horizontal gear (flat face towards the centre, shaft end 0.2 mm inside the gear), hub against the block — CA glue.
2. Vertical gear on the long shaft (111.3 mm), flat face down, 29.8 mm above the bottom end of the shaft — glue. Shaft into the floor socket, mesh the gears.
3. Dome over the shaft (it passes through the central tube), 3× M3×10.
4. Wheel onto the shaft (hub towards the wall, ~0.5 mm gap), knob on an M3×25 with a washer.

**Gears and leaves (all versions)**
1. Central gear onto the coupler / shaft.
2. Small gears (15 t): sleeve A (11.4 mm) in the gear → gear onto an upper boss, mesh with the centre → washer → M3×18 tightened fully (the screw clamps the sleeve; the gear spins freely).
3. Large gears (24 t): sleeve B (11.0 mm) → gear onto a lower boss between two small ones, rock it until it drops into both → washer → M3×18. Turn it without leaves — it must run smoothly.
4. Leaves: slender on the small gears, wide on the large ones, crown leaf on the centre. Any angle. Optionally a drop of CA.

## Troubleshooting
- Catches at one point of the turn → blob on a tooth or sleeves A/B swapped; remove the large gears one at a time.
- A large gear won't drop in → inserts not flush, or the print is scaled.
- Motor hums → more duty (knob / `DUTY_MIN`), check the cell and the PTC.
- Wobbly leaves → the `BL` parameter in `parts.py`.

## Source
`source/` — `pip install manifold3d trimesh numpy`, then `python build_all.py`. After changing tooth counts, re-solve RO with `layout_solver.py`, otherwise the network will jam.

Inspired by the work of @mechdesign98; the geometry and all parts were designed from scratch. © Marcin Mazurek, 2026.
