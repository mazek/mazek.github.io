/* =====================================================================
   SWARM PUCK — firmware (ESP32, Arduino core 2.x i 3.x) — v2.1
   (v2.1: kompatybilność z Arduino-ESP32 core 3.x — nowe API ledc)
   ---------------------------------------------------------------------
   Zachowanie: krążek NIGDY nie ma się zderzyć z innym krążkiem ani ze
   ścianą — zamiast tego ma AKTYWNIE UCIEKAĆ. Dwie warstwy bezpieczeństwa:

     1) Warstwa proporcjonalna ("pole potencjału odpychającego") —
        wektor "ucieczki" liczony jako suma wkładów z 6 czujników ToF.
     2) Twardy override — poniżej CRITICAL_MM krążek natychmiast robi
        pełny ruch wsteczny, niezależnie od warstwy 1.

   ZMIANY W v2 (względem pierwszej wersji):
     - Czujniki VL53L0X: zamiast 6 pinów XSHUT używamy multipleksera I2C
       TCA9548A — wszystkie 6 czujników ma ten sam adres (0x29), mux po
       prostu przełącza, który jest aktywny. Uwalnia 6 GPIO.
     - Dźwięk: zamiast prostego piezo (fala prostokątna z ledcWriteTone)
       generujemy CZYSTY SINUS przez I2S na wzmacniacz MAX98357A + mały
       głośnik. Synteza działa w OSOBNYM ZADANIU (FreeRTOS task) na
       drugim rdzeniu ESP32, więc dźwięk jest płynny i nie zależy od
       tego, jak szybko/wolno kręci się główna pętla (odczyt czujników
       bywa wolny — patrz komentarz w loop()). To daje dużo lepszą
       kontrolę jakości: częstotliwość I głośność są niezależnymi
       parametrami, a docelowo można tu dograć obwiednię, wibrato,
       harmoniczne albo nawet odtwarzanie krótkich próbek/melodii.

   WYMAGANE BIBLIOTEKI (Arduino IDE -> Menedżer bibliotek):
     - Adafruit VL53L0X
     - Adafruit NeoPixel
   (driver/i2s.h i FreeRTOS są częścią rdzenia ESP32 — nic dodatkowego
   nie trzeba instalować)

   Kąty czujników (SENSOR_ANGLES_DEG) i kolejność kanałów multipleksera
   (MUX_CHANNEL) MUSZĄ odpowiadać fizycznemu montażowi w obudowie
   (patrz puck_enclosure.scad, tof_angles).
   ===================================================================== */

#include <Wire.h>
#include <Adafruit_VL53L0X.h>
#include <Adafruit_NeoPixel.h>
#include <driver/i2s.h>
#include <freertos/FreeRTOS.h>
#include <freertos/task.h>

// ---------------------------------------------------------------------
// PRZYPISANIE PINÓW — sprawdź z rozpiską GPIO swojej płytki ESP32!
// (Poniższe pasują do typowego 38-pinowego dev-kitu, np. NodeMCU-32S)
// ---------------------------------------------------------------------
static const uint8_t PIN_SDA = 21;
static const uint8_t PIN_SCL = 22;

static const uint8_t PIN_STBY = 4;
static const uint8_t PIN_AIN1 = 16, PIN_AIN2 = 17, PIN_PWMA = 5;   // lewy silnik
static const uint8_t PIN_BIN1 = 18, PIN_BIN2 = 19, PIN_PWMB = 23;  // prawy silnik

static const uint8_t PIN_WS2812     = 32;
static const uint8_t PIN_STATUS_LED = 15;

static const uint8_t PIN_I2S_BCLK = 25;  // MAX98357A: BCLK
static const uint8_t PIN_I2S_LRC  = 26;  // MAX98357A: LRC / WS
static const uint8_t PIN_I2S_DOUT = 27;  // MAX98357A: DIN

// ---------------------------------------------------------------------
// CZUJNIKI ToF przez multiplekser I2C TCA9548A
// ---------------------------------------------------------------------
static const uint8_t TCA9548A_ADDR = 0x70;
static const uint8_t NUM_SENSORS = 6;
// który kanał multipleksera (0-7) odpowiada któremu fizycznemu czujnikowi —
// dopasuj do własnego okablowania
static const uint8_t MUX_CHANNEL[NUM_SENSORS] = {0, 1, 2, 3, 4, 5};
// 0° = przód krążka; MUSI zgadzać się z tof_angles w pliku .scad
static const int     SENSOR_ANGLES_DEG[NUM_SENSORS] = {0, 60, 120, 180, 240, 300};

// ---------------------------------------------------------------------
// PARAMETRY ZACHOWANIA — do dostrojenia po pierwszych testach
// ---------------------------------------------------------------------
static const float DETECT_RANGE_MM = 500.0;   // powyżej tego dystansu: "czysto", brak reakcji
static const float CRITICAL_MM      = 70.0;    // poniżej tego: twardy manewr awaryjny (wsteczny)
static const float SENSOR_TIMEOUT_MM = 8190.0; // VL53L0X zwraca ~8190 gdy "poza zasięgiem"

static const int   BASE_SPEED   = 170;   // 0-255, prędkość "ucieczki" przy pełnej pilności
static const int   MIN_TURN_PWM = 60;    // minimalny PWM żeby silnik ruszył przy samym skręcie
static const float KP_TURN      = 2.2;   // wzmocnienie skrętu proporcjonalnego do błędu kąta

static const unsigned long ESCAPE_BURST_MS = 350; // czas trwania manewru awaryjnego (ms)

static const float SPEAKER_MIN_FREQ = 300.0;  // Hz — daleko / brak zagrożenia
static const float SPEAKER_MAX_FREQ = 2200.0; // Hz — bardzo blisko przeszkody
static const float SPEAKER_MIN_VOL  = 0.15;   // 0..1 — głośność gdy coś ledwo w zasięgu
static const float SPEAKER_MAX_VOL  = 0.9;    // 0..1 — głośność tuż przed CRITICAL_MM

// ---------------------------------------------------------------------
// OBIEKTY GLOBALNE
// ---------------------------------------------------------------------
Adafruit_VL53L0X sensors[NUM_SENSORS];
bool sensorOk[NUM_SENSORS];
float distanceMm[NUM_SENSORS];

Adafruit_NeoPixel pixels(NUM_SENSORS, PIN_WS2812, NEO_GRB + NEO_KHZ800);

const int PWM_FREQ = 20000;
const int PWM_RES  = 8;      // 8-bit -> 0-255
const int CH_MOTOR_A = 0;
const int CH_MOTOR_B = 1;

enum RobotState { STATE_NORMAL, STATE_ESCAPE };
RobotState state = STATE_NORMAL;
unsigned long escapeStartedAt = 0;

// cel dla zadania syntezy dźwięku — czytane/zapisywane z dwóch rdzeni,
// stąd volatile (proste float na ESP32 są odczytywane/zapisywane atomowo)
volatile float g_targetFreqHz = 0.0;
volatile float g_targetVolume = 0.0;

// =======================================================================
// SETUP
// =======================================================================
void setup() {
  Serial.begin(115200);
  delay(200);

  pinMode(PIN_STATUS_LED, OUTPUT);
  motorsInit();
  pixels.begin();
  pixels.setBrightness(80);
  pixels.show();

  Wire.begin(PIN_SDA, PIN_SCL);
  initSensors();

  audioInit();
  // zadanie syntezy dźwięku na rdzeniu 0 — Arduino loop() domyślnie działa na
  // rdzeniu 1, więc dźwięk jest całkowicie niezależny od tempa głównej pętli
  xTaskCreatePinnedToCore(audioTask, "audio", 4096, NULL, 1, NULL, 0);

  Serial.println(F("Swarm puck gotowy."));
}

// =======================================================================
// GLOWNA PETLA
// =======================================================================
void loop() {
  readAllSensors();

  float minDist = SENSOR_TIMEOUT_MM;
  for (uint8_t i = 0; i < NUM_SENSORS; i++) {
    if (sensorOk[i] && distanceMm[i] < minDist) minDist = distanceMm[i];
  }

  // --- WARSTWA 2: twardy override bezpieczeństwa -----------------------
  if (minDist < CRITICAL_MM && state != STATE_ESCAPE) {
    state = STATE_ESCAPE;
    escapeStartedAt = millis();
  }

  if (state == STATE_ESCAPE) {
    setMotor(0, -255);
    setMotor(1, -255);
    if (millis() - escapeStartedAt > ESCAPE_BURST_MS) {
      state = STATE_NORMAL;
    }
  } else {
    // --- WARSTWA 1: pole potencjału odpychającego (ucieczka) ----------
    float vx = 0, vy = 0;
    for (uint8_t i = 0; i < NUM_SENSORS; i++) {
      if (!sensorOk[i]) continue;
      float d = constrain(distanceMm[i], 0, DETECT_RANGE_MM);
      if (d >= DETECT_RANGE_MM) continue;
      float weight = (DETECT_RANGE_MM - d) / DETECT_RANGE_MM; // 0..1, silniejsze gdy bliżej
      float ang = radians((float)SENSOR_ANGLES_DEG[i]);
      // uciekamy w kierunku PRZECIWNYM do wykrytej przeszkody
      vx += -weight * cos(ang);
      vy += -weight * sin(ang);
    }

    float urgency = constrain(sqrt(vx * vx + vy * vy), 0.0, 1.0);

    if (urgency < 0.02) {
      setMotor(0, 0);
      setMotor(1, 0);
      // Przykład opcjonalnego "błądzenia" gdy nic nie zagraża:
      // setMotor(0, 40); setMotor(1, -40);
    } else {
      float headingErr = degrees(atan2(vy, vx));
      float turn = constrain(KP_TURN * headingErr, -255.0, 255.0);

      float headingErrRad = radians(headingErr);
      float fwd = BASE_SPEED * urgency * max(0.0f, (float)cos(headingErrRad));

      int left  = (int)(fwd - turn);
      int right = (int)(fwd + turn);

      if (abs(left) > 5 && abs(left) < MIN_TURN_PWM)  left  = (left  > 0 ? MIN_TURN_PWM : -MIN_TURN_PWM);
      if (abs(right) > 5 && abs(right) < MIN_TURN_PWM) right = (right > 0 ? MIN_TURN_PWM : -MIN_TURN_PWM);

      setMotor(0, constrain(left,  -255, 255));
      setMotor(1, constrain(right, -255, 255));
    }
  }

  updateProximityLeds();
  updateSpeakerTarget(minDist); // tylko ustawia cel (częstotliwość/głośność) dla audioTask
  heartbeatStatusLed();

  // UWAGA WYDAJNOŚCIOWA: rangingTest() jest FUNKCJĄ BLOKUJĄCĄ — pojedynczy odczyt
  // VL53L0X w trybie domyślnym trwa ~30-50ms, więc 6 czujników po kolei może dać
  // pętlę rzędu 5-8 Hz. Dźwięk NIE ucierpi na tym (osobne zadanie/rdzeń), ale
  // reakcja na ruch/skręt tak — do szybszej reakcji przełącz czujniki na tryb
  // ciągły: startRangeContinuous() + isRangeComplete()/readRangeResult().
  delay(5);
}

// =======================================================================
// CZUJNIKI ToF (VL53L0X) przez multiplekser I2C TCA9548A
// =======================================================================
void tcaSelect(uint8_t channel) {
  if (channel > 7) return;
  Wire.beginTransmission(TCA9548A_ADDR);
  Wire.write(1 << channel);
  Wire.endTransmission();
}

void initSensors() {
  for (uint8_t i = 0; i < NUM_SENSORS; i++) {
    tcaSelect(MUX_CHANNEL[i]);
    sensorOk[i] = sensors[i].begin(); // domyślny adres 0x29 — każdy czujnik jest
                                       // izolowany na własnym kanale multipleksera
    if (!sensorOk[i]) {
      Serial.print(F("Blad inicjalizacji czujnika #"));
      Serial.println(i);
    }
    distanceMm[i] = SENSOR_TIMEOUT_MM;
  }
}

void readAllSensors() {
  for (uint8_t i = 0; i < NUM_SENSORS; i++) {
    if (!sensorOk[i]) continue;
    tcaSelect(MUX_CHANNEL[i]);
    VL53L0X_RangingMeasurementData_t m;
    sensors[i].rangingTest(&m, false);
    if (m.RangeStatus != 4) { // 4 = poza zasięgiem / błąd pomiaru
      distanceMm[i] = m.RangeMilliMeter;
    } else {
      distanceMm[i] = SENSOR_TIMEOUT_MM;
    }
  }
}

// =======================================================================
// STEROWNIK SILNIKÓW (TB6612FNG)
// =======================================================================
void motorsInit() {
  pinMode(PIN_STBY, OUTPUT);
  digitalWrite(PIN_STBY, HIGH);
  pinMode(PIN_AIN1, OUTPUT); pinMode(PIN_AIN2, OUTPUT);
  pinMode(PIN_BIN1, OUTPUT); pinMode(PIN_BIN2, OUTPUT);

#if ESP_ARDUINO_VERSION_MAJOR >= 3
  // Arduino-ESP32 core 3.x: ledcSetup/ledcAttachPin usunięte, kanał = pin
  ledcAttach(PIN_PWMA, PWM_FREQ, PWM_RES);
  ledcAttach(PIN_PWMB, PWM_FREQ, PWM_RES);
#else
  ledcSetup(CH_MOTOR_A, PWM_FREQ, PWM_RES);
  ledcAttachPin(PIN_PWMA, CH_MOTOR_A);
  ledcSetup(CH_MOTOR_B, PWM_FREQ, PWM_RES);
  ledcAttachPin(PIN_PWMB, CH_MOTOR_B);
#endif
}

// ledcWrite: w core 3.x adresuje się PINEM, w 2.x kanałem
inline void motorPwm(int ch, uint8_t pin, int duty) {
#if ESP_ARDUINO_VERSION_MAJOR >= 3
  ledcWrite(pin, duty);
#else
  ledcWrite(ch, duty);
#endif
}

void setMotor(int side, int speed) {
  speed = constrain(speed, -255, 255);
  bool in1 = speed >= 0;
  bool in2 = speed < 0;
  if (side == 0) {
    digitalWrite(PIN_AIN1, in1);
    digitalWrite(PIN_AIN2, in2);
    motorPwm(CH_MOTOR_A, PIN_PWMA, abs(speed));
  } else {
    digitalWrite(PIN_BIN1, in1);
    digitalWrite(PIN_BIN2, in2);
    motorPwm(CH_MOTOR_B, PIN_PWMB, abs(speed));
  }
}

// =======================================================================
// DIODY WS2812B — sygnalizacja bliskości, kierunkowo (1 dioda / czujnik)
// =======================================================================
void updateProximityLeds() {
  for (uint8_t i = 0; i < NUM_SENSORS; i++) {
    float d = sensorOk[i] ? constrain(distanceMm[i], 0, DETECT_RANGE_MM) : DETECT_RANGE_MM;
    float ratio = (DETECT_RANGE_MM - d) / DETECT_RANGE_MM;
    uint8_t r = (uint8_t)(255 * ratio);
    uint8_t g = (uint8_t)(255 * (1.0 - ratio));
    pixels.setPixelColor(i, pixels.Color(r, g, 0));
  }
  pixels.show();
}

// =======================================================================
// GŁOŚNIK I2S (MAX98357A) — czysty sinus, częstotliwość + głośność rosną
// im bliżej NAJBLIŻSZA przeszkoda. Synteza próbek dzieje się w audioTask(),
// tutaj tylko ustawiamy cel (ze zwykłym wygładzeniem, żeby uniknąć "klików"
// przy nagłych skokach odległości).
// =======================================================================
void updateSpeakerTarget(float minDist) {
  float targetFreq, targetVol;
  if (minDist >= DETECT_RANGE_MM) {
    targetFreq = 0;
    targetVol = 0;
  } else {
    float d = constrain(minDist, CRITICAL_MM, DETECT_RANGE_MM);
    float t = (DETECT_RANGE_MM - d) / (DETECT_RANGE_MM - CRITICAL_MM); // 0..1, blisko->1
    targetFreq = SPEAKER_MIN_FREQ + t * (SPEAKER_MAX_FREQ - SPEAKER_MIN_FREQ);
    targetVol  = SPEAKER_MIN_VOL  + t * (SPEAKER_MAX_VOL  - SPEAKER_MIN_VOL);
  }
  // wygładzanie (filtr jednobiegunowy) — łagodniejsze zmiany tonu/głośności
  const float SMOOTH = 0.25;
  g_targetFreqHz = g_targetFreqHz + SMOOTH * (targetFreq - g_targetFreqHz);
  g_targetVolume = g_targetVolume + SMOOTH * (targetVol  - g_targetVolume);
}

void audioInit() {
  i2s_config_t cfg = {
    .mode = (i2s_mode_t)(I2S_MODE_MASTER | I2S_MODE_TX),
    .sample_rate = 16000,
    .bits_per_sample = I2S_BITS_PER_SAMPLE_16BIT,
    .channel_format = I2S_CHANNEL_FMT_ONLY_LEFT,
    .communication_format = (i2s_comm_format_t)(I2S_COMM_FORMAT_STAND_I2S),
    .intr_alloc_flags = 0,
    .dma_buf_count = 6,
    .dma_buf_len = 256,
    .use_apll = false,
    .tx_desc_auto_clear = true
  };
  i2s_pin_config_t pins = {
    .bck_io_num = PIN_I2S_BCLK,
    .ws_io_num = PIN_I2S_LRC,
    .data_out_num = PIN_I2S_DOUT,
    .data_in_num = I2S_PIN_NO_CHANGE
  };
  i2s_driver_install(I2S_NUM_0, &cfg, 0, NULL);
  i2s_set_pin(I2S_NUM_0, &pins);
}

// Zadanie FreeRTOS — ciągła synteza sinusa (DDS z akumulatorem fazy),
// działa niezależnie od głównej pętli. Miejsce do rozbudowy: obwiednia
// ADSR, wibrato, harmoniczne, albo odtwarzanie próbek z pamięci flash.
void audioTask(void *pv) {
  const int SAMPLE_RATE = 16000;
  const int BUF_LEN = 256;
  static int16_t buf[BUF_LEN];
  float phase = 0.0;

  for (;;) {
    float freq = g_targetFreqHz;
    float vol  = g_targetVolume;
    for (int i = 0; i < BUF_LEN; i++) {
      if (freq > 1.0) {
        phase += 2.0 * PI * freq / SAMPLE_RATE;
        if (phase >= 2.0 * PI) phase -= 2.0 * PI;
        buf[i] = (int16_t)(sinf(phase) * 30000.0f * vol);
      } else {
        buf[i] = 0;
      }
    }
    size_t bytesWritten;
    i2s_write(I2S_NUM_0, buf, sizeof(buf), &bytesWritten, portMAX_DELAY);
  }
}

// =======================================================================
// DIODA STATUSU — proste "bicie serca"
// =======================================================================
void heartbeatStatusLed() {
  static unsigned long lastToggle = 0;
  static bool ledOn = false;
  if (millis() - lastToggle > 600) {
    ledOn = !ledOn;
    digitalWrite(PIN_STATUS_LED, ledOn);
    lastToggle = millis();
  }
}
