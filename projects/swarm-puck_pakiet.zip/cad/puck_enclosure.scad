// ======================================================================
// SWARM PUCK — parametryczna obudowa do druku 3D (szkic roboczy)
// ----------------------------------------------------------------------
// Wszystkie wymiary komponentów oznaczone [ZMIERZ] to wartości typowe
// z kart katalogowych — PRZED DRUKIEM zmierz suwmiarką konkretnie
// zakupione egzemplarze i popraw zmienne poniżej (różni producenci mają
// niewielkie odchyłki na tanich modułach z Chin).
//
// Układ współrzędnych: X+ = "przód" krążka (0°), kąty liczone jak w
// matematyce (przeciwnie do wskazówek zegara), Z+ = w górę.
// ======================================================================

$fn = 64;

// ---------------- Ogólne wymiary krążka ----------------
puck_od   = 120;   // średnica zewnętrzna krążka
wall_t    = 2.6;   // grubość ścianki bocznej
base_h    = 34;    // wysokość dolnej części (base) — silniki, bateria, elektronika
                   // (podniesiona z 28 do 34mm, żeby zmieścić realne koło Pololu 32x7mm)
lid_h     = 12;    // wysokość pokrywy (lid) — znacznik ArUco + LED
floor_t   = 2.4;   // grubość dna

inner_r = puck_od/2 - wall_t;

// ---------------- Silniki N20 (bez enkodera — firmware go i tak nie odczytuje) ----------------
// Konkretny produkt: Botland "Micro motor N20-BT41 100:1 150RPM - 6V" (5904422306700) [ZMIERZ]
// Zrezygnowano z enkodera z pierwszej wersji — upraszcza montaż/okablowanie, a że firmware
// go nie wykorzystuje (kalibracja przez PWM zamiast domykania pętli), nie ma strat.
motor_l   = 25;    // długość samego korpusu silnika (bez enkodera), wzdłuż osi wału
motor_w   = 12;
motor_h   = 20;
shaft_d   = 3.4;   // luz na wałek D-shape 3mm
shaft_len = 6;     // wałek + piasta koła, odległość od korpusu silnika do zewnętrznej ścianki

// ---------------- Koło ----------------
// Konkretny produkt: Pololu 1087/1088 "Wheel 32x7mm" (czarne/białe) — projektowane wprost
// pod wałek N20, z gumową/silikonową oponką. Stąd base_h podniesione do 34mm (patrz wyżej).
wheel_od = 32;
wheel_w  = 7;   // szerokość koła (wzdłuż osi wałka / promieniowo względem krążka)
axle_z   = wheel_od/2;                        // wysokość osi napędowej nad podłogą — koło MUSI
                                               // dotykać podłogi (z=0), więc to NIE jest miejsce
                                               // na dodawanie luzu (patrz caster_mount_h do tego)
motor_pedestal_h = max(axle_z - motor_h/2 - floor_t, 0);

// ---------------- "Spódnica" zakrywająca koła i wystający bok silników ----------------
// Szerszy, cienki pierścień otaczający cały krążek na wysokości kół — z zewnątrz nie widać
// kół ani "uszu" silników, widać tylko gładki, szerszy krążek. Koła nadal dotykają podłogi:
// spódnica kończy się kawałek NAD podłogą (skirt_lift), więc nie szoruje o ziemię.
// Wysokość spódnicy jest ograniczona przez base_h (spódnica nie może wejść w pokrywę!).
skirt_extra  = 13;                  // o ile promieniowo spódnica wystaje poza główny walec
skirt_od     = puck_od + 2*skirt_extra;
skirt_wall_t = 2.2;
skirt_lift   = 3;                   // prześwit pod spódnicą (koło dotyka podłogi, spódnica nie)
skirt_h      = base_h - skirt_lift - 1; // sięga prawie do górnej krawędzi base (1mm zapasu do pokrywy)

// ---------------- Kółko samonastawne (caster) ----------------
// Pololu #950 — Ball Caster with 3/8" Plastic Ball [ZMIERZ]
caster_hole_spacing = 13.6;  // 0.53"
caster_screw_d       = 3.4;  // otwór na wkręt M3
caster_boss_d        = 9;
caster_mount_h       = 6;    // WYSOKOŚĆ DO DOSTROJENIA po pierwszym teście (musi zrównać poziom krążka z kołami)

// ---------------- Akumulator LiPo 903048 (700-1000 mAh, złącze JST-PH) ----------------
batt_l = 52; // z zapasem na taśmę/przewody
batt_w = 32;
batt_h = 11;

// ---------------- ESP32 DevKit (np. "NodeMCU-32S" / ESP32-WROOM-32, 38 pinów) ----------------
// Wybrany zamiast mniejszego ESP32-C3, bo potrzeba ok. 18 GPIO (6x XSHUT czujników ToF,
// I2C, sterownik silników, WS2812B, brzęczyk, LED statusu) — 38-pinowy dev-kit ma zapas.
// [ZMIERZ dokładnie na swoim egzemplarzu — obudowa opiera płytkę na tolerancyjnej półce,
//  więc liczy się głównie obrys, nie rozstaw otworów]
mcu_l = 55;
mcu_w = 28;
mcu_t = 1.8;

// ---------------- Sterownik silników — SparkFun TB6612FNG (ROB-14450) ----------------
drv_l = 27;
drv_w = 19;
drv_t = 3;

// ---------------- Ładowarka TP4056 (typowy moduł z ochroną, micro-USB) ----------------
chg_l = 26;
chg_w = 17;
chg_t = 4;
usb_cut_w = 9;   // wycięcie w ściance na złącze micro-USB
usb_cut_h = 4.5;

// ---------------- Czujnik ToF VL53L0X ----------------
// Adafruit VL53L0X STEMMA QT breakout (#3317) [ZMIERZ]
tof_l = 21;
tof_w = 18;
tof_t = 3;
tof_window_w = 10;   // okno w ściance na optykę czujnika
tof_window_h = 6;
tof_z = 15;          // wysokość środka okna nad podłogą
tof_angles = [0, 60, 120, 180, 240, 300];  // 0° = przód krążka

// ---------------- Multiplekser I2C TCA9548A (zamiast 6 osobnych pinów XSHUT) ----------------
// Uwalnia 6 GPIO w ESP32 (potrzebnych teraz na I2S do głośnika) — wszystkie 6 czujników
// wisi na jednej magistrali I2C, mux przełącza który jest aktywny (patrz firmware).
mux_l = 20;
mux_w = 17;
mux_t = 2;

// ---------------- Dioda LED sygnalizująca bliskość (WS2812B 5050, adresowalna) ----------------
// 6 diod, po jednej nad każdym czujnikiem ToF — świeci tym mocniej/bardziej na czerwono
// im bliżej przeszkoda wykryta w danym kierunku (patrz firmware)
led_win_d    = 5.5;   // okno w ściance, przez które świeci dioda
led_pcb      = 5.5;   // rozmiar pojedynczego "pixela" WS2812B (kwadratowa płytka)
led_z_offset = 9;     // dioda nad oknem czujnika ToF (przesunięcie w Z względem tof_z)

// ---------------- Głośniczek + wzmacniacz I2S sygnalizujący bliskość dźwiękiem ----------------
// Zamiast prostego piezo (tylko fala prostokątna, słaba jakość) — mały głośnik sterowany
// cyfrowo przez I2S, np. Adafruit MAX98357A "I2S 3W Class D Amplifier Breakout" (#3006)
// + mały głośnik 23mm 4-8Ω/1-3W (np. CUI CMS-232 lub podobny generyczny "23mm speaker").
// Dzięki I2S da się generować dowolny kształt fali (czysty sinus, obwiednie, nawet melodie
// z próbek) i pełną kontrolę głośności/barwy z poziomu ESP32 — patrz firmware.
speaker_d       = 27;   // średnica głośnika (BOM: Speaker YD27 27x5mm)
speaker_pocket_h = 5;   // głębokość gniazda w pokrywie (YD27 ma 5mm grubości)
speaker_vent_d  = 2.2;  // średnica otworów akustycznych
speaker_r       = 41;   // promień położenia gniazda na pokrywie — POZA kwadratem znacznika ArUco
speaker_angle   = 180;  // oś 180° (wolna od wkrętów 40/90/270/322°)

// Płytka wzmacniacza MAX98357A (montowana wewnątrz base, sektor ok. 20°) [ZMIERZ]
amp_l = 20;
amp_w = 28;
amp_t = 3;

aruco_size = 50;   // bok kwadratowego znacznika ArUco [mm]

// pomocnicza dioda statusu (bateria/tryb pracy), osobna od 6 diod bliskości
status_led_r     = 45;
status_led_angle = 45;

// ---------------- Śruby łączące base + lid ----------------
// Kąty dobrane RĘCZNIE tak, żeby trafić w wolne miejsca między czujnikami ToF (0,60,120,
// 180,240,300°) a uchwytami: sterownika (150°), ładowarki (210°), wzmacniacza (20°) i
// multipleksera (340°) — jeśli zmienisz rozmieszczenie czujników/uchwytów, popraw też kąty.
screw_d      = 3.2;  // M3 samogwintujący
boss_od      = 8;
screw_angles = [40, 90, 270, 322];  // 90/270 pokrywają się z osiami silników, ale na innej
                                     // wysokości (śruba nisko przy dnie, wałek wyżej) — bez kolizji

// ======================================================================
// POMOCNICZE MODUŁY
// ======================================================================

// Prostokątne wycięcie w ściance bocznej, na danym kącie i wysokości środka.
// Domyślnie przewierca TYLKO główną ściankę (base); ustaw through_skirt=true dla okien,
// które muszą też przebić szerszą "spódnicę" na zewnątrz (czujniki, LED, port USB) —
// wszystkie mieszczą się w zakresie wysokości spódnicy (skirt_lift..skirt_lift+skirt_h).
module wall_cutout(angle, z_center, w, h, through_skirt=false) {
    depth = through_skirt ? (skirt_od/2 - inner_r + 4) : (wall_t+2);
    rotate([0,0,angle])
        translate([inner_r-1, -w/2, z_center-h/2])
            cube([depth, w, h]);
}

// Okrągły otwór przelotowy przez ściankę (np. na wałek silnika), promieniowo
module wall_round_hole(angle, z_center, d, depth) {
    rotate([0,0,angle])
        translate([inner_r-1, 0, z_center])
            rotate([0,90,0])
                cylinder(d=d, h=depth+2);
}

// Para szyn "card-edge" trzymających płytkę PCB wsuwaną od góry (kierunek Z)
// len = wysokość szyn (pionowo), wid = szerokość płytki którą obejmują
module vertical_card_rails(rail_height, board_w, rail_w=2, gap=0.6) {
    // szyny wpuszczone 0.8mm w podłogę (z=-0.8), żeby zespoliły się z korpusem
    // w jedną bryłę (bez osobnych, "wiszących" na styk powierzchni components w meshu)
    for (s = [-1,1])
        translate([0, s*(board_w/2+gap/2+rail_w/2), -0.8])
            cube([rail_w+2, rail_w, rail_height+0.8], center=false);
}

// ======================================================================
// BASE (dolna część) — silniki, bateria, elektronika
// ======================================================================

motor_r_near = inner_r - shaft_len - motor_l; // bliżej środka
motor_r_far  = inner_r - shaft_len;           // bliżej ścianki (koniec wału)
motor_r_mid  = (motor_r_near + motor_r_far)/2;

module motor_mount(side) {           // side = +1 (lewy, 90°) / -1 (prawy, 270°)
    ang = (side > 0) ? 90 : 270;
    rotate([0,0,ang])
    translate([motor_r_mid, 0, 0]) {
        // podstawka podnosząca silnik na wysokość osi kół
        if (motor_pedestal_h > 0.5)
            translate([0,0,floor_t])
                cube([motor_l+2, motor_w+5, motor_pedestal_h], center=true);
        // ścianki boczne pozycjonujące korpus silnika
        for (sy = [-1,1])
            translate([0, sy*(motor_w/2+1.6), floor_t+motor_pedestal_h])
                cube([motor_l+2, 2, motor_h*0.55], center=true);
        // dwa podłużne sloty w podstawce na opaskę zaciskową (zip-tie) mocującą silnik
        for (xx = [-motor_l/2+7, motor_l/2-7])
            translate([xx, 0, floor_t-0.1])
                cube([3, motor_w*0.7, motor_pedestal_h+floor_t+0.4], center=true);
    }
    // otwór na wałek silnika w ściance zewnętrznej
    wall_round_hole(ang, axle_z, shaft_d, wall_t+6);
}

module caster_mount() {
    // krążek stoi na: 2 koła (przód/tył wg silników na 90/270) + kółko z tyłu (180°)
    rotate([0,0,180])
    translate([inner_r-18, 0, 0]) {
        for (s=[-1,1])
            translate([0, s*caster_hole_spacing/2, 0]) {
                cylinder(d=caster_boss_d, h=floor_t+caster_mount_h);
            }
    }
}
module caster_screw_holes() {
    rotate([0,0,180])
    translate([inner_r-18, 0, -1]) {
        for (s=[-1,1])
            translate([0, s*caster_hole_spacing/2, 0])
                cylinder(d=caster_screw_d, h=floor_t+caster_mount_h+2);
    }
}

// Komora baterii + poziome mocowanie ESP32 NAD baterią.
// Zamiast słupków przebijających baterię (kolidowałyby z nią) albo uchwytu na ściance
// zewnętrznej (zabrakłoby miejsca obok czujników), ESP32 wsuwa się POZIOMO (wzdłuż X)
// na szynach osadzonych na szczycie dwóch ścianek bocznych komory baterii — z dala od
// ścianki zewnętrznej krążka, więc zero konfliktu kątowego z czujnikami/uchwytami.
module battery_and_mcu_mount() {
    deck_z = floor_t + batt_h + 3; // wysokość półki ESP32 nad dnem
    wall_y = batt_w/2 + 0.5;       // (odsunięte tak, by nie dotykać wnęk silników przy 90/270°)
    // krótkie ścianki czołowe pozycjonujące baterię wzdłuż jej długości (X),
    // wpuszczone w podłogę (fuzja z korpusem)
    for (sx=[-1,1])
        translate([sx*(batt_l/2+2), 0, floor_t+0.9])
            cube([3, batt_w+2, 3], center=true);
    // wyższe ścianki wzdłuż długich boków baterii (Y) — POPRAWKA: wcześniej były
    // center=true na wysokości floor_t, przez co ich SZCZYT kończył się na ~z=11mm,
    // a półki ESP32 leżały na z~16mm => WISIAŁY w powietrzu (floating). Teraz ścianki
    // rosną od podłogi (z=floor_t-0.6, wpuszczone) aż DO deck_z, więc realnie podpierają
    // półki. Jednocześnie pozycjonują baterię.
    wall_h = deck_z - (floor_t - 0.6);
    for (sy=[-1,1])
        translate([0, sy*wall_y, (floor_t - 0.6 + deck_z)/2])
            cube([batt_l+4, 3, wall_h], center=true);
    // półki na szczycie ścianek, wystające do środka — ESP32 kładziony na nich poziomo.
    // Zachodzą na szczyt ścianek (deck_z), więc zespalają się w bryłę (nie floating).
    for (sy=[-1,1])
        translate([0, sy*(wall_y-2.5), deck_z-0.5])
            cube([mcu_l+6, 5, 3], center=true);
}

module driver_bracket() {
    // sterownik TB6612 — sektor ok. 150°, szyny przy ściance, wsuwany od góry
    ang = 150;
    rotate([0,0,ang])
        translate([inner_r-drv_t-1.5, 0, floor_t])
            vertical_card_rails(base_h-floor_t-3, drv_l);
}

module charger_bracket() {
    // ładowarka TP4056 — sektor ok. 210°, szyny przy ściance (wycięcie na micro-USB
    // jest wycinane osobno, w difference() bloku base() — patrz wywołanie z through_skirt=true)
    ang = 210;
    rotate([0,0,ang])
        translate([inner_r-chg_t-1.5, 0, floor_t])
            vertical_card_rails(base_h-floor_t-3, chg_l);
}

module sensor_bracket(angle) {
    // szyny trzymające krawędzie płytki VL53L0X, wsuwana od góry (okno w ściance/spódnicy
    // jest wycinane osobno, w difference() bloku base())
    rotate([0,0,angle])
        translate([inner_r-tof_t-1.5, 0, floor_t])
            vertical_card_rails(base_h-floor_t-2, tof_w);
}

// Okno w ściance + spódnicy dla diody LED sygnalizującej bliskość — nad oknem czujnika ToF
module led_window(angle) {
    wall_cutout(angle, tof_z+led_z_offset, led_win_d, led_win_d, through_skirt=true);
}

// Uchwyt płytki wzmacniacza I2S (MAX98357A) — sektor ok. 20°
module amp_bracket() {
    ang = 20;
    rotate([0,0,ang])
        translate([inner_r-amp_t-1.5, 0, floor_t])
            vertical_card_rails(base_h-floor_t-3, amp_w);
}

// Uchwyt multipleksera I2C (TCA9548A) — sektor ok. 340°
module mux_bracket() {
    ang = 340;
    rotate([0,0,ang])
        translate([inner_r-mux_t-1.5, 0, floor_t])
            vertical_card_rails(base_h-floor_t-3, mux_w);
}

// ---------------- Żebra-rampy spódnicy (KLUCZOWE dla druku bez podpór) ----------------
// PROBLEM: goła spódnica to cienki pierścień, którego dolna krawędź startuje 3mm
// NAD stołem (skirt_lift) — dla slicera to wielki "floating island" (druk się nie
// uda albo wymaga dużo podpór w trudnym do usunięcia miejscu pod spódnicą).
// ROZWIĄZANIE: gęsto rozstawione (co 12°) żebra łączące główną ściankę ze spódnicą.
// Każde żebro ma DÓŁ W FORMIE ŁAGODNEJ RAMPY (~15° od poziomu — poniżej 45°, więc
// druk samonośny): zakotwione przy stole na głównej ściance (r=puck_od/2, z=0) i
// wznoszące się do dolnej krawędzi spódnicy (z=skirt_lift). Dzięki temu:
//   • żebro nie tworzy nowego kontaktu z podłogą poza obrysem korpusu (rampa unosi
//     się od razu za ścianką) — spódnica NADAL nie szoruje o ziemię,
//   • dolna krawędź spódnicy jest podparta co 12°, więc jej pierwsza warstwa to
//     seria krótkich (~15 mm) mostków między żebrami zamiast jednego pierścienia
//     wiszącego w powietrzu — to drukuje się bez podpór.
skirt_fin_th     = 2;                       // grubość (styczna) żebra
skirt_gap_r0     = puck_od/2;               // wewn. koniec żebra (przy głównej ściance)
skirt_gap_r1     = skirt_od/2 - skirt_wall_t; // zewn. koniec (wewn. ścianka spódnicy)
skirt_fin_top    = skirt_lift + 7;          // niskie żebra gringujące (poniżej okna ToF,
                                            // żeby nie zasłaniać wiązki czujnika)
skirt_rib_top    = skirt_lift + skirt_h - 6;// wysokie żebra usztywniające (tylko w
                                            // sektorach bez czujników i bez kół)

// Pojedyncze żebro-rampa: profil (promień, wysokość) wyciągnięty na grubość skirt_fin_th.
// Dolna krawędź idzie skosem (skirt_gap_r0,0) -> (skirt_gap_r1,skirt_lift) = rampa ~15°.
module skirt_fin(top_z) {
    // małe zakłady (overlap) w obie ścianki, żeby żebro zespoliło się w bryłę (manifold)
    r0 = skirt_gap_r0 - 1.5;   // wchodzi w główną ściankę
    r1 = skirt_gap_r1 + 0.6;   // wchodzi w ściankę spódnicy
    rotate([90,0,0])
        linear_extrude(height=skirt_fin_th, center=true)
            polygon([
                [r0, 0],
                [r1, skirt_lift],
                [r1, top_z],
                [r0, top_z]
            ]);
}

// "Spódnica" zakrywająca koła — patrz opis przy zmiennych skirt_*
module wheel_skirt() {
    difference() {
        translate([0,0,skirt_lift])
            cylinder(d=skirt_od, h=skirt_h);
        translate([0,0,skirt_lift-1])
            cylinder(d=skirt_od-2*skirt_wall_t, h=skirt_h+2);
    }
    // Gęste NISKIE żebra-rampy co 12° — grunt/podparcie dolnej krawędzi spódnicy.
    // Kończą się poniżej okien czujników (z<12mm), więc mogą stać nawet na kątach
    // czujników bez zasłaniania wiązki. Siatka 12° z natury omija środek kół (90/270).
    for (a = [0:12:359])
        if (!((a >= 84 && a <= 96) || (a >= 264 && a <= 276)))  // koło Ø32 zajmuje ±14° wokół 90/270 — żebra 84/96/264/276 wchodziłyby w nie
            rotate([0,0,a]) skirt_fin(skirt_fin_top);
    // WYSOKIE żebra usztywniające — tylko w wolnych sektorach (między czujnikami,
    // z dala od kół i portu USB), też z rampą u dołu (zagruntowane, druk bez podpór).
    for (a = [22,68,112,158,202,248,292,338])
        rotate([0,0,a]) skirt_fin(skirt_rib_top);
}
// Mała półka wewnątrz, na której osadza się (klejem) pojedynczy pixel WS2812B
module led_shelf(angle) {
    // POPRAWKA: wcześniej półka kończyła się ~0.5mm przed ścianką (r 52.9..56.9 vs
    // wewn. ścianka 57.4) => WISIAŁA. Teraz sięga w ściankę (do ~r=60), więc jest
    // podparta/zespolona. Otwór okna LED i tak wycina się później w difference().
    z = tof_z + led_z_offset;
    rotate([0,0,angle])
        translate([inner_r-4, -led_pcb/2-1, z-2])
            cube([6.5, led_pcb+2, 4]);
}

module screw_bosses(h, hole_depth) {
    for (a = screw_angles)
        rotate([0,0,a])
            translate([inner_r-boss_od/2-0.5, 0, 0]) {
                difference() {
                    cylinder(d=boss_od, h=h);
                    translate([0,0,h-hole_depth])
                        cylinder(d=screw_d, h=hole_depth+1);
                }
            }
}

module base() {
    difference() {
        union() {
            cylinder(d=puck_od, h=base_h);  // pełny walec zewnętrzny
            wheel_skirt();                  // szersza "spódnica" zakrywająca koła z boku
        }
        // wydrążenie środka (otwarty góra, dno = floor_t)
        translate([0,0,floor_t])
            cylinder(d=puck_od-2*wall_t, h=base_h);
        // otwory na wałki silników (koło zostaje UKRYTE w przestrzeni pod spódnicą —
        // nie trzeba przewiercać samej spódnicy, tylko główną ściankę)
        wall_round_hole(90,  axle_z, shaft_d, wall_t+6);
        wall_round_hole(270, axle_z, shaft_d, wall_t+6);
        // okna na 6 czujników ToF — przez ściankę I przez spódnicę (through_skirt=true)
        for (a = tof_angles)
            wall_cutout(a, tof_z, tof_window_w, tof_window_h, through_skirt=true);
        // okna na 6 diod LED sygnalizujących bliskość (nad czujnikami ToF)
        for (a = tof_angles)
            led_window(a);
        // wycięcie na micro-USB ładowarki — też przez spódnicę
        wall_cutout(210, floor_t+chg_w/2+2, usb_cut_w, usb_cut_h, through_skirt=true);
        // otwory pod wkręty kółka samonastawnego
        caster_screw_holes();
    }
    // elementy montażowe wewnątrz
    motor_mount(1);
    motor_mount(-1);
    caster_mount();
    battery_and_mcu_mount();
    driver_bracket();
    charger_bracket();
    amp_bracket();
    mux_bracket();
    for (a = tof_angles) sensor_bracket(a);
    for (a = tof_angles) led_shelf(a);
    screw_bosses(8, 5);
}

// ======================================================================
// LID (pokrywa) — znacznik ArUco + LED, łączona wkrętami z base
// ======================================================================

module speaker_pocket() {
    bx = speaker_r*cos(speaker_angle);
    by = speaker_r*sin(speaker_angle);
    // gniazdo na głośniczek 23mm, wklejany od spodu pokrywy
    translate([bx, by, lid_h-speaker_pocket_h])
        cylinder(d=speaker_d+1.5, h=speaker_pocket_h+0.5);
    // otwory akustyczne, żeby dźwięk wydostawał się na zewnątrz (siatka otworów, nie tylko obwód)
    translate([bx, by, lid_h-1])
        cylinder(d=speaker_vent_d, h=2);
    for (rr=[5,9])
        for (a=[0:45:315])
            translate([bx+rr*cos(a), by+rr*sin(a), lid_h-1])
                cylinder(d=speaker_vent_d, h=2);
}

module lid() {
    sx = status_led_r*cos(status_led_angle);
    sy = status_led_r*sin(status_led_angle);
    difference() {
        union() {
            cylinder(d=puck_od, h=lid_h);
            // pierścień wchodzący "na wcisk" do wnętrza base dla wyśrodkowania
            translate([0,0,-4])
                cylinder(d=puck_od-2*wall_t-0.6, h=4.2);
        }
        // wgłębienie na wydrukowany/wyklejony znacznik ArUco — kwadrat 50x50mm
        // (min. dla kamery pod sufitem; głośnik leży poza nim, patrz speaker_r/angle)
        translate([-aruco_size/2,-aruco_size/2,lid_h-0.6])
            cube([aruco_size, aruco_size, 1]);
        // otwór na diodę LED statusu (bateria/tryb pracy) — osobną od 6 diod bliskości w ściance
        translate([sx,sy,-1])
            cylinder(d=5, h=lid_h+2);
        // gniazdo + otwory akustyczne na głośniczek sygnalizujący bliskość dźwiękiem
        speaker_pocket();
        // otwory pod wkręty (przelotowe, łebek chowany od góry)
        for (a = screw_angles)
            rotate([0,0,a])
                translate([inner_r-boss_od/2-0.5, 0, -1]) {
                    cylinder(d=screw_d, h=lid_h+2);
                    translate([0,0,lid_h-3])
                        cylinder(d=6.5, h=4); // gniazdo na łeb wkrętu
                }
    }
}

// ======================================================================
// KOŁO (drukowane) — piasta na wałek D-shape + rowek na gumową "oponkę"
// ----------------------------------------------------------------------
// Sam wydruk (PETG/PLA) prawie nie ma przyczepności do gładkiej podłogi —
// dlatego koło ma kształt "krążka pasowego" (2 kołnierze + węższy środek),
// w który wkłada się gumkę recepturkę / o-ring / pasek ciętej dętki
// rowerowej jako bieżnik. Piasta ma otwór w kształcie litery D (pasujący
// na wałek silnika N20) + promieniowy otwór na wkręt dociskowy (grub screw)
// M2, żeby koło się nie ślizgało na wałku pod obciążeniem/przy zderzeniu.
// ======================================================================
wheel_flange_w    = 1.6;   // szerokość każdego z 2 bocznych kołnierzy
wheel_groove_r    = 2.2;   // o ile węższy promieniowo jest środkowy rowek na oponkę
wheel_shaft_d     = 3.0;   // RZECZYWISTA średnica wałka N20 (nie mylić z shaft_d = luz w ściance!)
wheel_shaft_flat  = 0.5;   // głębokość ścięcia "D" na wałku (typowe dla N20 ~0.4-0.5mm)
wheel_hub_screw_d = 2.0;   // otwór pilotowy na wkręt samogwintujący M2 (docisk do wałka)

module d_shaft_hole(d, flat, length) {
    translate([0, 0, -length/2 - 0.5])
    difference() {
        cylinder(d=d, h=length+1, $fn=32);
        translate([d/2 - flat, -d, 0])
            cube([d, 2*d, length+1]);
    }
}

module wheel() {
    difference() {
        union() {
            // 2 kołnierze boczne (utrzymują oponkę z obu stron)
            translate([0,0,-wheel_w/2+wheel_flange_w/2])
                cylinder(d=wheel_od, h=wheel_flange_w, center=true);
            translate([0,0, wheel_w/2-wheel_flange_w/2])
                cylinder(d=wheel_od, h=wheel_flange_w, center=true);
            // środkowy rdzeń (węższy) — tu siedzi naciągnięta gumka/o-ring jako bieżnik
            cylinder(d=wheel_od - 2*wheel_groove_r, h=wheel_w, center=true);
        }
        // otwór na wałek (D-shape)
        d_shaft_hole(wheel_shaft_d + 0.15, wheel_shaft_flat, wheel_w + 2);
        // promieniowy otwór na wkręt dociskowy, prostopadle do ścięcia D
        rotate([0,0,90])
            rotate([90,0,0])
                translate([0,0,-(wheel_od-2*wheel_groove_r)/2 - 1])
                    cylinder(d=wheel_hub_screw_d, h=(wheel_od-2*wheel_groove_r)/2+2, $fn=16);
    }
}

// ======================================================================
// MOCKUPY KOMPONENTÓW — tylko do wizualizacji rozmieszczenia montażu.
// NIE wchodzą do differencje/union w base()/lid() i NIE trafiają do
// eksportu STL — to uproszczone bryły (bounding-box realnych modułów)
// w kolorach, żeby pokazać GDZIE i JAK CO MA BYĆ ZAMONTOWANE.
// Kolory = legenda (patrz opis w odpowiedzi/README).
// ======================================================================

module motor_mockup(side) {
    ang = (side > 0) ? 90 : 270;
    color([0.2,0.2,0.2])
        rotate([0,0,ang])
            translate([motor_r_mid,0,axle_z])
                cube([motor_l, motor_w, motor_h], center=true);
}

module wheel_mockup(side) {
    ang = (side > 0) ? 90 : 270;
    color([0.05,0.05,0.05])
        rotate([0,0,ang])
            translate([inner_r+wheel_w/2+1, 0, axle_z])
                rotate([0,90,0])
                    cylinder(d=wheel_od, h=wheel_w, center=true);
}

module caster_mockup() {
    color([0.55,0.55,0.55])
        rotate([0,0,180])
            translate([inner_r-18,0,-3])
                sphere(d=9.5);
    color([0.3,0.45,0.3])
        rotate([0,0,180])
            translate([inner_r-18,0,-1])
                cube([16,16,2], center=true);
}

module battery_mockup() {
    color([0.15,0.55,0.2])
        translate([0,0,floor_t+batt_h/2])
            cube([batt_l,batt_w,batt_h], center=true);
}

module mcu_mockup() {
    deck_z = floor_t + batt_h + 3;
    color([0.1,0.3,0.8])
        translate([0,0,deck_z+mcu_t/2+0.5])
            cube([mcu_l,mcu_w,mcu_t], center=true);
}

// Wspólny helper dla płytek wsuwanych w szyny (driver/charger/amp/mux/tof) —
// odtwarza tę samą geometrię co bracket_*() ale jako pełna bryła w kolorze
module bracket_mockup(angle, thickness, y_extent, z_extent, z_center, col) {
    color(col)
        rotate([0,0,angle])
            translate([inner_r-thickness/2-1.5, 0, z_center])
                cube([thickness, y_extent, z_extent], center=true);
}

module driver_mockup()  { bracket_mockup(150, drv_t, drv_l, drv_w, floor_t+drv_w/2+3, [0.9,0.5,0.0]); }
module charger_mockup() { bracket_mockup(210, chg_t, chg_l, chg_w, floor_t+chg_w/2+3, [0.6,0.1,0.6]); }
module amp_mockup()     { bracket_mockup(20,  amp_t, amp_w, amp_l, floor_t+amp_l/2+3, [0.9,0.85,0.1]); }
module mux_mockup()     { bracket_mockup(340, mux_t, mux_w, mux_l, floor_t+mux_l/2+3, [0.0,0.65,0.65]); }

module tof_mockups() {
    for (a = tof_angles)
        bracket_mockup(a, tof_t, tof_w, tof_l, tof_z, [0.85,0.1,0.1]);
}

module led_mockups() {
    for (a = tof_angles)
        color([1,0.35,0.65])
            rotate([0,0,a])
                translate([inner_r-4.5,0,tof_z+led_z_offset])
                    cube([4,led_pcb,4], center=true);
}

// Głośnik + dioda statusu — we WSPÓŁRZĘDNYCH LOKALNYCH pokrywy (wywołuj
// dopiero PO translate([0,0,base_h]), tak jak samą lid())
module speaker_mockup() {
    bx = speaker_r*cos(speaker_angle);
    by = speaker_r*sin(speaker_angle);
    color([0.25,0.08,0.08])
        translate([bx,by,lid_h-speaker_pocket_h/2-1])
            cylinder(d=speaker_d, h=speaker_pocket_h, center=true);
}
module status_led_mockup() {
    sx = status_led_r*cos(status_led_angle);
    sy = status_led_r*sin(status_led_angle);
    color([1,0.9,0.2])
        translate([sx,sy,lid_h-2])
            cylinder(d=4, h=3);
}

module components() {
    motor_mockup(1);  motor_mockup(-1);
    wheel_mockup(1);  wheel_mockup(-1);
    caster_mockup();
    battery_mockup();
    mcu_mockup();
    driver_mockup();
    charger_mockup();
    amp_mockup();
    mux_mockup();
    tof_mockups();
    led_mockups();
}

module components_lid() {
    speaker_mockup();
    status_led_mockup();
}

// ======================================================================
// WIDOK MONTAŻOWY (do podglądu) — ustaw MODE poniżej
// ======================================================================

MODE = "assembled";

if (MODE == "base") {
    base();
} else if (MODE == "lid") {
    lid();
} else if (MODE == "assembled") {
    base();
    translate([0,0,base_h]) lid();
} else if (MODE == "exploded") {
    base();
    translate([0,0,base_h+25]) lid();
} else if (MODE == "wheel") {
    wheel();
} else if (MODE == "internals") {
    // Base + wszystkie komponenty widoczne od góry (pokrywa zdjęta celowo,
    // żeby było widać rozmieszczenie montażu). Obudowa w neutralnym
    // szarobłękicie, żeby żaden kolor komponentu się z nią nie mylił.
    color([0.55,0.63,0.72]) base();
    components();
} else if (MODE == "internals_lid") {
    // To samo, ale z półprzezroczystą pokrywą na miejscu (kontekst całości)
    color([0.55,0.63,0.72]) base();
    components();
    translate([0,0,base_h]) {
        color([0.75,0.85,1,0.22]) lid();
        components_lid();
    }
} else if (MODE == "section") {
    // Przekrój połówkowy (Y>=0) całości złożonej — pokazuje układ WARSTW
    // w pionie (silnik/oś kół vs. bateria+ESP32 vs. pokrywa)
    intersection() {
        union() {
            color([0.55,0.63,0.72]) base();
            components();
            translate([0,0,base_h]) {
                color([0.6,0.68,0.76]) lid();
                components_lid();
            }
        }
        translate([-200,0,-50]) cube([400,200,400]);
    }
}
