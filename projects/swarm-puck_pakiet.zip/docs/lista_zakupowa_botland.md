# Lista zakupowa — 1 prototyp krążka (Botland)

Ilości poniżej są na **jeden egzemplarz** (prototyp). Przy zamawianiu na całą serię (kilkanaście sztuk) pomnóż kolumnę "Ilość/szt." przez liczbę krążków — dla pozycji sprzedawanych w parach (silniki, koła) pamiętaj, że "Ilość/szt." już uwzględnia, że kupujesz odpowiednią liczbę par/paczek.

Nie mam bezpośredniego dostępu do koszyka Botland (brak integracji z ich sklepem w tej sesji), więc nie mogę dodać tych pozycji do koszyka automatycznie — poniżej są gotowe linki do kliknięcia. Część cen nie dała się pobrać automatycznie (strony ładują się dynamicznie) — przed zamówieniem zweryfikuj cenę i dostępność na stronie produktu.

| # | Komponent | Konkretny produkt | Ilość/szt. | Link |
|---|---|---|---|---|
| 1 | Silnik | Micro motor N20-BT41 100:1 150RPM - 6V | 2 | [botland.store](https://botland.store/n20-micro-motors-mp-series-medium-power/12603-micro-motor-n20-bt41-100-1-150rpm-6v-5904422306700.html) |
| 2 | Koła | Pololu Wheel 32×7mm (para), czarne #1087 | 1 para | [botland.store](https://botland.store/wheels-with-tires/12-wheels-32x7mm-black-2pcs-pololu-1087-5903351247924.html) |
| 3 | Kółko samonastawne | Pololu Ball Caster 3/8" plastikowa kulka #950 | 1 | [botland.store](https://botland.store/reference-balls/30-ball-caster-38-plastic-pololu-950-5903351240765.html) |
| 4 | Sterownik silników | Moduł z TB6612FNG — dwukanałowy sterownik silników DC, Pololu #713 | 1 | [botland.store](https://botland.store/motor-drivers-modules/32-tb6612fng-two-channel-motor-controller-135v-1a-pololu-713.html) |
| 5 | Mikrokontroler | ESP32-DevKitC-32E V4, moduł ESP-WROOM-32E | 1 | [botland.store](https://botland.store/esp32-wifi-and-bt-modules/8306-esp32-devkitc-32e-v4-wifi-bt-42-platform-with-the-module-esp-wroom-32e-5904422336394.html) |
| 6 | Czujnik ToF | VL53L0X, Pololu #2490, do 200cm | 6 | [botland.store](https://botland.store/sensors-of-light-and-color/7176-vl53l0x-time-of-flight-distance-and-ambient-light-sensor-i2c-200cm-max-pololu-2490-5904422308513.html) |
| 7 | Multiplekser I2C | TCA9548A, Adafruit #2717 | 1 | [botland.store](https://botland.store/multiplexers/4915-tca9548a-module-with-multiplexer-i2c-adafruit-2717-5904422354268.html) |
| 8 | Diody LED bliskości | Moduł z pojedynczym pikselem WS2812B | 7 (6 + 1 zapas) | [botland.store](https://botland.store/led-diodes/2290-pixel-module-with-addressed-rgb-led-ws2812b-5904422300494.html) |
| 9 | Wzmacniacz audio | MAX98357A — dekoder stereo DAC I2S, SparkFun DEV-14809 | 1 | [botland.store](https://botland.store/mp3-wav-ogg-midi-players/13062-max98357a-decoder-stereo-dac-i2s-sparkfun-dev-14809-5903351249676.html) |
| 10 | Głośnik | Speaker YD27, 0.5W, 8Ω, 27×5mm | 1 | [botland.store](https://botland.store/analog-speakers/3471-speaker-yd27-05w-8ohm-27x5mm-5903351245876.html) |
| 11 | Akumulator | Akyga Li-Pol 1000mAh 1S 3.7V, JST-BEC, 48×30×7mm | 1 | [botland.store](https://botland.store/battery-li-pol-1s-37-v/15613-akyga-li-pol-cell-1000mah-1s-37v-jst-bec-connector-socket-48x30x7mm-5904422324230.html) |
| 12 | Ładowarka | TP4056 1S 3.7V microUSB, z zabezpieczeniem | 1 | [botland.store](https://botland.store/chargers/6944-li-ion-charger-tp4056-1s-37v-microusb-with-protection-5904422375355.html) |

## Poza Botland (drobiazgi)

- Śruby M3×8 samogwintujące (do łączenia base+lid, ~4-6 szt.) i śruby dociskowe M2×3-4 (jeśli drukujesz koła zamiast kupować Pololu) — najprościej z Amazon.pl jako zestaw asortymentowy, Botland nie ma dobrego odpowiednika w wyszukiwaniu.
- Przewody połączeniowe (żeńsko-żeńskie/męsko-żeńskie), ew. złącza JST — jeśli nie masz już w domowym zapasie.

## Zmiana w projekcie, o której warto wiedzieć

Podczas researchu znalazłem realny, sprawdzony produkt na koła (Pololu 32×7mm, zaprojektowany wprost pod wałek N20) — jest on nieco większy niż wcześniej założone w modelu 26mm. Zaktualizowałem plik `puck_enclosure.scad` (wysokość `base_h` z 28mm na 34mm), żeby koło się mieściło pod "spódnicą" — wysyłam poprawione pliki STL (w tym zaktualizowany `puck_wheel.stl` z finalną średnicą 32mm). Zrezygnowałem też z enkodera na silniku z wcześniejszej wersji BOM: firmware i tak go nie odczytuje, więc prostszy i tańszy silnik bez enkodera nic nie traci funkcjonalnie.

**Korekta pozycji #4:** słusznie zauważyłeś, że sam układ TB6612FNG to goła kostka SMD (nie do lutowania na kolanie) — link poprawiony na gotowy moduł/carrier (Pololu #713) z wyprowadzonymi pinami, dokładnie taki, jaki zakłada firmware i schemat podłączeń.
