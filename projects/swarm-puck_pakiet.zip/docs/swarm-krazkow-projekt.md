> **Uwaga (26.11.2026):** to dokument startowy. Aktualny stan: README.md i docs/WERYFIKACJA.md (mux I2C zamiast XSHUT, bez enkoderów, dodane LED/głośnik, kosztorys nieaktualny).

# Swarm robotów w kształcie krążka hokejowego — specyfikacja projektu

Dokument podsumowuje architekturę, listę komponentów i plan budowy dla roju kilkunastu autonomicznych urządzeń, obserwowanych i mapowanych z poziomu komputera w zamkniętym pomieszczeniu.

## 1. Założenia przyjęte na podstawie rozmowy

- Rozmiar krążka: zwiększony względem prawdziwego hokejowego — ok. Ø100–120 mm, wysokość 30–40 mm. To minimum, żeby zmieścić baterię, dwa silniki, elektronikę i czujniki bez własnej płytki PCB.
- Napęd: dwa koła różnicowe (jedno po każdej stronie) + jedno kółko samonastawne (caster) z przodu lub z tyłu jako trzeci punkt podparcia. Pozwala to na ruch w dowolnym kierunku i obrót w miejscu.
- Elektronika: gotowe moduły (ESP32 dev board, gotowe breakouty czujników), bez projektowania własnego PCB na start.
- Lokalizacja: rekomendowane rozwiązanie to kamera zamontowana pod sufitem + znaczniki wizualne (ArUco/AprilTag) na górze każdego krążka, z pozycjonowaniem liczonym na komputerze (OpenCV). To najtańsza i najprostsza metoda, a przy okazji naturalnie łączy się z wymaganiem „wizualizacji na komputerze" — ten sam obraz z kamery, który wykrywa pozycje, może od razu zasilać widok mapy.

## 2. Architektura systemu — przegląd

Rój składa się z trzech warstw:

1. **Krążki (agenci)** — każdy ma własny mikrokontroler, napęd, czujniki zbliżeniowe i znacznik lokalizacyjny na wierzchu. Krążki mogą działać autonomicznie (reagować na przeszkody) i/lub raportować dane przez WiFi do komputera centralnego.
2. **Kamera + komputer centralny** — kamera pod sufitem widzi całe pomieszczenie, program w Pythonie (OpenCV) wykrywa znaczniki ArUco na każdym krążku, liczy pozycję (x, y) i orientację (kąt), i wysyła tę mapę do wizualizacji oraz opcjonalnie z powrotem do krążków (jeśli chcesz sterować rojem centralnie).
3. **Warstwa komunikacji** — WiFi + MQTT (broker np. Mosquitto uruchomiony na tym samym komputerze). Każdy krążek publikuje dane z czujników zbliżeniowych, subskrybuje ewentualne komendy. To prostsze niż mesh ESP-NOW przy kilkunastu urządzeniach i łatwiej się debuguje.

## 3. Mechanika i obudowa (druk 3D)

- Kształt: dwuczęściowa obudowa (podstawa + pokrywa), łączona wkrętami M2/M3 lub zatrzaskami — łatwy dostęp do baterii i elektroniki przy serwisowaniu kilkunastu sztuk.
- Materiał: PETG (dobra udarność, krążki będą się zderzać ze sobą i ze ścianami) zamiast PLA, które jest kruche przy uderzeniach. TPU jako opcjonalny miękki zderzak naklejony/nadrukowany na obwodzie zmniejszy hałas i uszkodzenia przy kolizjach.
- Rozmieszczenie masy: silniki i bateria nisko i blisko środka dla stabilności; ważne żeby środek ciężkości był nisko, bo krążek będzie często się zderzał.
- Otwory na obwodzie co ok. 60° na czujniki zbliżeniowe (patrz sekcja 4) — 6 otworów daje pełne pokrycie 360°.
- Górna powierzchnia: płaskie miejsce na wydrukowany/wyklejony znacznik ArUco (min. ok. 5×5 cm dla wiarygodnego rozpoznania z kamery pod sufitem) + ewentualnie dioda LED sygnalizacyjna widoczna z góry (stan baterii, tryb pracy).
- Koła: gotowe kółka do silników N20 (np. 42 mm średnicy) + kółko samonastawne (ball caster) jako trzeci punkt podparcia.

## 4. Napęd

| Element | Rekomendacja | Uwagi |
|---|---|---|
| Silniki | 2× silnik N20 z przekładnią, najlepiej wersja z wbudowanym enkoderem | Enkodery pozwalają wyrównać prędkość obu kół (tanie silniki mają spory rozrzut), co daje bardziej przewidywalny tor jazdy |
| Sterownik silników | TB6612FNG (2-kanałowy) | Mniejszy i sprawniejszy niż popularny L298N, dobrze pasuje do małych silników N20 |
| Koła | Gumowe kółka 40–42 mm | Dobra przyczepność na gładkiej podłodze |
| Trzeci punkt podparcia | Kółko samonastawne (ball caster) | Stabilizuje krążek bez ograniczania skrętu |

## 5. Czujniki zbliżeniowe (360°)

Rekomendacja: **6× czujnik ToF VL53L0X** (breakout, I2C, zasięg do ok. 1–2 m), rozmieszczone co 60° na obwodzie krążka — każdy „patrzy" promieniście na zewnątrz i mierzy odległość do najbliższej przeszkody (inny krążek albo ściana) w swoim sektorze.

Ponieważ wszystkie sztuki VL53L0X mają domyślnie ten sam adres I2C, potrzebny jest jeden z dwóch sposobów obsługi wielu czujników na jednej magistrali:

- **Piny XSHUT** — każdy czujnik ma pin wyłączający, który podłączasz do osobnego GPIO ESP32 i po kolei włączasz/przypisujesz unikalny adres I2C przy starcie. ESP32 ma wystarczająco dużo GPIO (30+), więc to rozwiązanie tańsze i prostsze niż multiplekser.
- **Multiplekser I2C TCA9548A** — alternatywa, jeśli zabraknie GPIO albo wolisz mniej okablowania na płytce.

Alternatywy tańsze/prostsze, gdyby VL53L0X okazał się za drogi przy 6 sztukach na krążek: czujniki IR (Sharp GP2Y0A lub prostsze IR-reflective) — mniej precyzyjne, ale kilkukrotnie tańsze.

## 6. Lokalizacja i mapowanie (najważniejsza decyzja projektowa)

**Rekomendacja: kamera pod sufitem + znaczniki ArUco/AprilTag + OpenCV.**

Dlaczego to najlepszy wybór dla Twojego przypadku:

- Zero dodatkowej elektroniki na krążku poza wydrukowanym znacznikiem — obniża koszt i miejsce w obudowie.
- Jedna kamera (nawet dobra kamera USB/webcam 1080p, przy większym pomieszczeniu warto rozważyć kamerę o wyższej rozdzielczości lub szerokim kącie) widzi cały rój naraz — dokładnie to, czego potrzebujesz do obserwacji i mapowania.
- Biblioteka `cv2.aruco` w OpenCV robi wykrywanie znaczników, obliczanie pozycji (x, y) i orientacji (kąt) „z pudełka", w czasie rzeczywistym (dziesiątki klatek/s przy rozdzielczości 1080p).
- Wynik od razu można wizualizować (np. prosty dashboard w Pythonie z matplotlib na żywo, albo lekka aplikacja webowa z Canvas/Three.js, jeśli chcesz coś ładniejszego i dostępnego z przeglądarki).

Ograniczenia, o których warto wiedzieć:
- Wymaga stałego, niezasłoniętego pola widzenia kamery na całą podłogę — jeśli sufit jest bardzo wysoki albo pomieszczenie duże, potrzeba kamery o wyższej rozdzielczości albo kilku kamer zszytych w jeden obraz.
- Znaczniki muszą być czytelne z góry — krążek nie może się przewracać na bok (przy tym kształcie i niskim środku ciężkości to mało prawdopodobne).

Jeśli w przyszłości zechcesz niezależność od kamery (np. większe pomieszczenie, słabe oświetlenie, albo chcesz żeby same krążki znały swoją pozycję bez zewnętrznego systemu) — ścieżka rozwoju to moduły **UWB (Ultra-Wideband)**, np. Qorvo/Decawave DWM1001. Wymaga to jednak 3–4 stacjonarnych „kotwic" (anchors) rozstawionych w pomieszczeniu i jest wyraźnie droższe (moduł UWB to koszt zbliżony do samego ESP32 + reszty elektroniki krążka razem wziętych). Na start zdecydowanie polecam zacząć od kamery.

Opcjonalnie warto dodać na każdym krążku prosty **IMU (np. MPU6050)** — nie do lokalizacji bezwzględnej, ale jako tani czujnik orientacji/ruchu uzupełniający dane z kamery (np. gdy znacznik na chwilę zasłoni się przy zderzeniu dwóch krążków) i przydatny do sterowania napędem.

## 7. Elektronika i zasilanie na krążek

| Podsystem | Komponent | Uwagi |
|---|---|---|
| Mikrokontroler | ESP32 (dev board, np. ESP32-WROOM lub mniejszy ESP32-C3) | WiFi wbudowane, wystarczająco GPIO na 6 czujników przez XSHUT, programowalny z Arduino IDE lub PlatformIO |
| Zasilanie | Akumulator LiPo 3.7V, 500–1000 mAh | Dobierz pojemność do czasu pracy potrzebnego na jeden test (np. 500 mAh ≈ krótsze testy, łatwiejszy druk obudowy; 1000 mAh ≈ dłuższy czas pracy, cięższy krążek) |
| Ładowanie | Moduł TP4056 (z zabezpieczeniem) | Do ładowania pojedynczej celi LiPo |
| Regulator napięcia | Moduł step-down/step-up 5V lub 3.3V, zależnie od wymagań ESP32 i silników | Silniki N20 zwykle lepiej pracują przy nieco wyższym napięciu niż logika |
| Sterownik silników | TB6612FNG | patrz sekcja 4 |
| Czujniki zbliżeniowe | 6× VL53L0X | patrz sekcja 5 |
| Orientacja (opcjonalnie) | MPU6050 | patrz sekcja 6 |
| Wskaźnik stanu | 1× LED (widoczna z góry) | Status baterii/trybu pracy, przydatne przy kilkunastu sztukach na stole |

## 8. Oprogramowanie

**Firmware krążka (ESP32, Arduino/PlatformIO w C++, ewentualnie MicroPython):**
- Odczyt 6 czujników ToF, sterowanie silnikami (podstawowe zachowania: unikanie kolizji, prosta logika rojowa typu boids — separacja/wyrównanie/kohezja na podstawie odczytów zbliżeniowych).
- Publikacja danych z czujników przez WiFi/MQTT do komputera centralnego.
- Subskrypcja komend, jeśli chcesz też sterować rojem centralnie (np. wysyłać zadane prędkości kół).

**Komputer centralny (Python):**
- `OpenCV + cv2.aruco` — wykrywanie znaczników z obrazu kamery, obliczanie pozycji i orientacji każdego krążka co klatkę.
- Broker MQTT (np. Mosquitto) — zbiera dane z czujników zbliżeniowych ze wszystkich krążków.
- Warstwa wizualizacji — na start wystarczy `matplotlib` z odświeżaniem na żywo (szybkie do zrobienia); docelowo lekka aplikacja webowa (Flask/FastAPI + WebSocket + Canvas albo Three.js), żeby mieć ładną, interaktywną mapę roju z historią tras, wykresami odległości między krążkami itp.
- Logowanie danych (CSV/SQLite) do późniejszej analizy zachowania roju.

## 9. Szacunkowa lista zakupów (BOM) — na 1 sztukę i na 15 sztuk

| Komponent | Cena jednostkowa (szac.) | Ilość/szt. | Koszt/szt. |
|---|---|---|---|
| ESP32 dev board | ~15–25 zł | 1 | 15–25 zł |
| Silniki N20 z enkoderem (para) | ~30–50 zł | 1 para | 30–50 zł |
| Koła 40mm (para) | ~10–15 zł | 1 para | 10–15 zł |
| Kółko samonastawne (caster) | ~10 zł | 1 | 10 zł |
| Sterownik TB6612FNG | ~10 zł | 1 | 10 zł |
| VL53L0X breakout | ~15–20 zł | 6 | 90–120 zł |
| Akumulator LiPo 3.7V ~700mAh | ~20–30 zł | 1 | 20–30 zł |
| Moduł ładowania TP4056 | ~5 zł | 1 | 5 zł |
| Regulator napięcia | ~5–10 zł | 1 | 5–10 zł |
| MPU6050 (opcjonalnie) | ~10 zł | 1 | 10 zł |
| Filament PETG na obudowę | ~5–10 zł w materiale | — | 5–10 zł |
| Śruby, przewody, złącza, znacznik ArUco (wydruk) | ~10 zł | — | 10 zł |
| **Razem na 1 krążek** | | | **ok. 210–305 zł** |
| **Razem na 15 krążków** | | | **ok. 3150–4600 zł** |

Dodatkowo jednorazowo dla całego systemu:
- Kamera pod sufit — webcam 1080p wystarczy na start (~100–200 zł), kamera o wyższej rozdzielczości/szerszym kącie jeśli pomieszczenie jest duże (~300–600 zł).
- Uchwyt/statyw pod sufit do zamontowania kamery.
- Router WiFi dedykowany testom (żeby nie obciążać domowej sieci przy 15 urządzeniach na WiFi jednocześnie).

Ceny są orientacyjne (rynek komponentów elektronicznych zmienia się) — przed zakupem warto zweryfikować aktualne ceny u dostawców typu AliExpress/Botland/Kamami/DFRobot.

## 10. Plan budowy — fazowany

1. **Prototyp #1 (1 krążek)** — zbuduj i przetestuj jeden egzemplarz od zera: druk obudowy, montaż napędu, podłączenie jednego czujnika ToF, firmware podstawowy (jazda + unikanie przeszkody z 1 czujnika). Cel: sprawdzić czy geometria obudowy, napęd i bilans wagowy działają.
2. **Pełne wyposażenie prototypu** — dodaj pozostałe 5 czujników ToF, znacznik ArUco, test wykrywania pozycji kamerą, komunikację WiFi/MQTT.
3. **Kalibracja lokalizacji** — skalibruj kamerę (przekształcenie obrazu na współrzędne rzeczywiste pomieszczenia), przetestuj dokładność wykrywania znacznika ArUco w ruchu.
4. **Powielenie do kilkunastu sztuk** — po potwierdzeniu, że projekt działa, wydrukuj i zmontuj pozostałe egzemplarze. Warto na tym etapie rozważyć uproszczenia montażowe (np. przygotowane szablony do lutowania, złącza zamiast lutowania na stałe do serwisu).
5. **Testy roju** — uruchomienie kilkunastu krążków jednocześnie w zamkniętym pomieszczeniu, obserwacja zachowań (kolizje, zagęszczenia przy ścianach, zator sieci WiFi/MQTT przy wielu urządzeniach na raz — to częsty problem praktyczny przy tej skali, warto przetestować wcześniej z 3-4 sztukami).
6. **(Opcjonalnie) Docelowy custom PCB** — jeśli po testach projekt się sprawdzi i zechcesz go powielać dalej lub zmniejszyć rozmiar krążka, warto zaprojektować dedykowaną płytkę integrującą ESP32, sterownik silników i złącza czujników — mniej okablowania, mniejsza awaryjność przy kilkunastu sztukach.

## 11. Ryzyka i na co uważać

- **Rozrzut parametrów tanich silników N20** — bez enkoderów krążek będzie skręcał w bok zamiast jechać prosto; enkodery (lub przynajmniej kalibracja PWM per silnik) rozwiązują to.
- **Zasięg WiFi/MQTT przy 15 urządzeniach jednocześnie** — może pojawić się przeciążenie sieci lub brokera; warto przetestować przy mniejszej liczbie sztuk zanim zbudujesz wszystkie 15.
- **Bezpieczeństwo akumulatorów LiPo** — ładowanie kilkunastu ogniw jednocześnie wymaga uwagi (moduły z zabezpieczeniem, niepozostawianie bez nadzoru, docelowo rozważ stację ładującą zbiorczą).
- **Okluzja znacznika ArUco** — przy zderzeniu dwóch krążków znacznik jednego może się chwilowo zasłonić drugim krążkiem z perspektywy kamery pod sufitem, jeśli krążki są wysokie; niska wysokość (30–40mm) minimalizuje ten problem.
- **Kalibracja kamery** — zniekształcenia obiektywu (zwłaszcza szerokokątnego) trzeba skorygować (`cv2.calibrateCamera`), żeby mapa pozycji była metrycznie poprawna, a nie tylko wizualnie „ładna".

---

To jest plan startowy — możemy w kolejnym kroku np. dobrać konkretne modele komponentów dostępne u polskich dystrybutorów (Botland, Kamami), narysować szkic obudowy do druku 3D, albo napisać przykładowy kod firmware/wizualizacji.
