# Weryfikacja materiałów — Swarm Puck (stan: 26.11.2026)

Sprawdzono: kompilację OpenSCAD (base/lid/wheel → STL, "Simple: yes"), spójność .scad ↔ BOM ↔ firmware ↔ dokumentacja,
kolizje geometryczne (test przecięć w OpenSCAD) oraz zgodność firmware z bieżącym Arduino-ESP32.
Nie sprawdzono na sprzęcie — to weryfikacja papierowa/geometryczna.

## Poprawione w tej paczce

1. **Głośnik** — BOM: YD27 (27×5 mm), model: gniazdo na 23×4 mm. Teraz `speaker_d=27`, `speaker_pocket_h=5`.
2. **Głośnik nachodził na znacznik ArUco** — środek głośnika (r=44, 225°) leżał wewnątrz kwadratu 70×70 mm,
   a wgłębienie Ø76 nie mieściło nawet kwadratu 70×70. Teraz: znacznik 50×50 mm (min. z dokumentacji),
   głośnik na 180°, r=41, poza znacznikiem; kąt 180° wolny od wkrętów.
3. **Żebra spódnicy wchodziły w koła** — warunek `a>84 && a<96` nie wykluczał żeber 84/96/264/276°,
   które leżą w obrysie koła Ø32 (test przecięć: 36 ścianek kolizji, po poprawce zero).
   Skutek: w sektorach kół spódnica nie ma podparcia (patrz README, druk).
4. **Firmware vs. Arduino-ESP32 core 3.x** — `ledcSetup/ledcAttachPin` zostały usunięte w core 3.0,
   v2 by się nie skompilowało. v2.1 ma gałąź `#if ESP_ARDUINO_VERSION_MAJOR >= 3` (`ledcAttach`, `ledcWrite(pin)`).
   Nie kompilowano na urządzeniu (brak arduino-cli w środowisku) — skompiluj przed flashowaniem.
5. README: żeber niskich jest 26 (nie 30) + 8 wysokich.

## DO SPRAWDZENIA PRZED DRUKIEM (nie zmieniano)

**A. Oś kół a długość wałka N20 (krytyczne).** Przód korpusu silnika leży na r=51,4 mm, ścianka kończy się na r=60,
koło 7 mm stoi na ok. 60,5–67,5 mm. Wałek N20 ma zwykle ok. 9–10 mm → sięga do r≈61 mm, więc koło miałoby ~1 mm
zazębienia z wałkiem. Rozwiązania: (a) przesunąć silniki na zewnątrz (`shaft_len`≈0,5 — czoło silnika przy ściance),
wtedy trzeba też przesunąć wkręty `screw_angles` 90/270 (kolidują z silnikiem), albo (b) wałek dłuższy.
Zmierz wałek swojego silnika (Botland N20-BT41). Pozycja koła w `wheel_mockup` (r=inner_r+…) wchodzi w ściankę o ~2,6 mm — to tylko mockup.

**B. Zasilanie.** Brak przetwornicy 5 V w liście zakupów. ESP32-DevKitC ma LDO 3,3 V z dropoutem ~1,1 V,
więc z LiPo 3,0–4,2 V będzie niestabilnie (brownout przy rozładowaniu / szczytach silników). WS2812B też wymaga ~5 V.
Dodaj step-up do 5 V (na VIN/5V) i wyłącznik zasilania. Silnik N20 6 V na 3,7 V da ok. 90 obr/min →
ok. 0,15 m/s z kołem 32 mm; `BASE_SPEED=170` dostroisz w testach.

**C. Wymiary modułów z innych produktów niż w BOM** (wszystkie `[ZMIERZ]`): ToF — model Adafruit #3317, BOM Pololu #2490;
TB6612FNG — model SparkFun, BOM Pololu #713; MAX98357A — model Adafruit #3006, BOM SparkFun DEV-14809.

**D. Luz kół.** Ø obudowy ze spódnicą to 146 mm (dokument początkowy zakładał Ø100–120). Odnotuj przy planowaniu areny/kamery.

**E. Brak enkoderów** — silnik bez enkodera, firmware nie koryguje toru; krążek będzie lekko skręcał. Akceptowalne dla uciekania, nie dla dokładnych tras.

**F. Zakres.** Firmware realizuje tylko unikanie kolizji + sygnalizację. WiFi/MQTT, kamera ArUco/OpenCV i wizualizacja
z dokumentacji NIE są zaimplementowane. Pętla czujników ~5–8 Hz (rangingTest blokujący).

**G. `docs/swarm-krazkow-projekt.md`** to dokument startowy — część decyzji zmieniła się później (mux zamiast XSHUT,
bez enkoderów, doszły głośnik/LED/wzmacniacz; kosztorys nieaktualny).
