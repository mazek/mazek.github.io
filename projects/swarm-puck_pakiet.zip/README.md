# Swarm Puck — przewodnik po paczce

Rój (~15 szt.) autonomicznych robotów w kształcie krążka hokejowego. Napęd różnicowy
(2× silnik N20 + kółko samonastawne), 6× czujnik ToF dookoła, unikanie kolizji
(krążki aktywnie uciekają od siebie i ścian), sygnalizacja bliskości dźwiękiem (I2S)
i diodami LED (WS2812B), lokalizacja przez kamerę z góry (ArUco). Druk 3D + gotowe moduły.

## Zawartość

- `cad/puck_enclosure.scad` — parametryczny model obudowy (OpenSCAD), ŹRÓDŁO PRAWDY.
- `stl/` — puck_base.stl, puck_lid.stl, puck_wheel.stl (wygenerowane z .scad; manifold, "Simple: yes").
- `firmware/puck_swarm_firmware.ino` — firmware ESP32 v2.1 (Arduino-ESP32 core 2.x i 3.x).
- `docs/swarm-krazkow-projekt.md` — architektura i plan (stan z początku projektu, patrz uwaga w pliku).
- `docs/lista_zakupowa_botland.md` — konkretne produkty do zamówienia.
- `docs/WERYFIKACJA.md` — wyniki weryfikacji: co poprawiono, co jeszcze trzeba sprawdzić przed drukiem.
- `renders/` — podglądy PNG.

## Generowanie STL

W OpenSCAD ustaw `MODE` na dole pliku (`"base"` | `"lid"` | `"wheel"`) i wyeksportuj STL,
albo z CLI: `openscad -D 'MODE="base"' -o puck_base.stl cad/puck_enclosure.scad`.
Tryby podglądu: `assembled`, `exploded`, `internals`, `internals_lid`, `section`.

## Druk 3D

- **base**: dnem do stołu. Spódnica podparta żebrami-rampami co 12° (samonośne ~15°);
  w sektorach kół (84–96° i 264–276°) żeber nie ma — tam spódnica wymaga lokalnych podpór/mostków.
- **lid**: górną płaszczyzną do stołu. Wgłębienie na znacznik ArUco 50×50 mm; głośnik 27 mm obok niego.
- **wheel**: opcjonalne koło drukowane (domyślnie kupujesz Pololu 32×7).

## Przed drukiem — zmierz moduły oznaczone `[ZMIERZ]` i przeczytaj `docs/WERYFIKACJA.md`.
